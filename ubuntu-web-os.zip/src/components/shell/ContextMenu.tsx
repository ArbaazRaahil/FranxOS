/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import { FolderPlus, FilePlus, Image, Terminal, Monitor, RefreshCw } from 'lucide-react';

interface ContextMenuProps {
  x: number;
  y: number;
  isOpen: boolean;
  onClose: () => void;
  onCreateFolder: () => void;
  onCreateFile: () => void;
  onOpenSettings: (tab?: string) => void;
  onOpenTerminal: () => void;
}

export const ContextMenu: React.FC<ContextMenuProps> = ({
  x,
  y,
  isOpen,
  onClose,
  onCreateFolder,
  onCreateFile,
  onOpenSettings,
  onOpenTerminal,
}) => {
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClick);
    }
    return () => document.removeEventListener('mousedown', handleClick);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Keep menu within screen boundaries
  const adjustedX = Math.min(x, window.innerWidth - 220);
  const adjustedY = Math.min(y, window.innerHeight - 240);

  return (
    <div
      ref={menuRef}
      style={{ left: adjustedX, top: adjustedY }}
      className="fixed z-[9999] w-52 bg-[#252526]/95 backdrop-blur-xl border border-white/10 rounded-xl p-1.5 gnome-menu-shadow text-neutral-200 text-xs select-none shadow-2xl animate-in fade-in zoom-in-95 duration-100"
    >
      <button
        onClick={() => {
          onCreateFolder();
          onClose();
        }}
        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-[#E95420] hover:text-white transition-colors text-left font-medium"
      >
        <FolderPlus className="w-4 h-4" />
        <span>New Folder</span>
      </button>

      <button
        onClick={() => {
          onCreateFile();
          onClose();
        }}
        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-[#E95420] hover:text-white transition-colors text-left font-medium"
      >
        <FilePlus className="w-4 h-4" />
        <span>New Document</span>
      </button>

      <div className="h-px bg-white/10 my-1" />

      <button
        onClick={() => {
          onOpenTerminal();
          onClose();
        }}
        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-[#E95420] hover:text-white transition-colors text-left font-medium"
      >
        <Terminal className="w-4 h-4 text-emerald-400" />
        <span>Open in Terminal</span>
      </button>

      <div className="h-px bg-white/10 my-1" />

      <button
        onClick={() => {
          onOpenSettings('appearance');
          onClose();
        }}
        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-[#E95420] hover:text-white transition-colors text-left font-medium"
      >
        <Image className="w-4 h-4" />
        <span>Change Background...</span>
      </button>

      <button
        onClick={() => {
          onOpenSettings('display');
          onClose();
        }}
        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-[#E95420] hover:text-white transition-colors text-left font-medium"
      >
        <Monitor className="w-4 h-4" />
        <span>Display Settings</span>
      </button>
    </div>
  );
};
