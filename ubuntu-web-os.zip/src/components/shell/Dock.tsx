/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Terminal,
  Folder,
  Globe,
  FileText,
  Calculator,
  Calendar,
  Music,
  ShoppingBag,
  Settings,
  Image as ImageIcon,
  Bomb,
  Grid,
} from 'lucide-react';
import { AppId, SystemSettings, WindowInstance } from '../../types/os';
import { APPS_REGISTRY } from '../../data/appsData';

interface DockProps {
  settings: SystemSettings;
  openWindows: WindowInstance[];
  activeWindowId: string | null;
  onAppClick: (appId: AppId) => void;
  onToggleAppGrid: () => void;
  isAppGridOpen: boolean;
}

export const Dock: React.FC<DockProps> = ({
  settings,
  openWindows,
  activeWindowId,
  onAppClick,
  onToggleAppGrid,
  isAppGridOpen,
}) => {
  const [hoveredApp, setHoveredApp] = useState<string | null>(null);

  // App icon renderer helper
  const renderAppIcon = (icon: string, className = 'w-6 h-6') => {
    switch (icon) {
      case 'terminal':
        return <Terminal className={`${className} text-emerald-400`} />;
      case 'folder':
        return <Folder className={`${className} text-[#4a90d9] fill-[#4a90d9]/30`} />;
      case 'globe':
        return <Globe className={`${className} text-[#E95420]`} />;
      case 'file-text':
        return <FileText className={`${className} text-amber-400`} />;
      case 'calculator':
        return <Calculator className={`${className} text-neutral-200`} />;
      case 'calendar':
        return <Calendar className={`${className} text-red-400`} />;
      case 'music':
        return <Music className={`${className} text-purple-400`} />;
      case 'shopping-bag':
        return <ShoppingBag className={`${className} text-[#E95420]`} />;
      case 'settings':
        return <Settings className={`${className} text-neutral-300`} />;
      case 'image':
        return <ImageIcon className={`${className} text-cyan-400`} />;
      case 'bomb':
        return <Bomb className={`${className} text-red-500`} />;
      default:
        return <Terminal className={className} />;
    }
  };

  // Determine list of apps to show in dock: pinned apps + unpinned running apps
  const pinnedAppIds = Object.keys(APPS_REGISTRY).filter((k) => APPS_REGISTRY[k].isPinned) as AppId[];
  const runningAppIds = Array.from(new Set(openWindows.map((w) => w.appId)));
  const unpinnedRunning = runningAppIds.filter((id) => !pinnedAppIds.includes(id));
  const dockApps = [...pinnedAppIds, ...unpinnedRunning];

  const isLeft = settings.dockPosition === 'left';
  const iconSize = settings.dockIconSize || 48;

  return (
    <div
      className={`fixed z-[9980] transition-all select-none ${
        isLeft
          ? 'left-0 top-7 bottom-0 w-16 flex flex-col justify-between items-center py-2 bg-black/40 backdrop-blur-md border-r border-white/5'
          : 'bottom-0 left-0 right-0 h-16 flex flex-row justify-between items-center px-4 bg-black/40 backdrop-blur-md border-t border-white/5'
      }`}
    >
      {/* App Icons List */}
      <div
        className={`flex ${
          isLeft ? 'flex-col gap-2 overflow-y-auto' : 'flex-row gap-2 overflow-x-auto'
        } items-center`}
      >
        {dockApps.map((appId) => {
          const meta = APPS_REGISTRY[appId];
          if (!meta) return null;

          const windows = openWindows.filter((w) => w.appId === appId);
          const isRunning = windows.length > 0;
          const isActive = windows.some((w) => w.id === activeWindowId && !w.isMinimized);

          return (
            <div
              key={appId}
              className="relative flex items-center justify-center"
              onMouseEnter={() => setHoveredApp(appId)}
              onMouseLeave={() => setHoveredApp(null)}
            >
              {/* Running indicator pip */}
              {isRunning && (
                <div
                  className={`absolute rounded-full transition-all ${
                    isLeft
                      ? `left-0.5 top-1/2 -translate-y-1/2 w-1.5 ${
                          isActive ? 'h-4 bg-[#E95420]' : 'h-1.5 bg-white/70'
                        }`
                      : `bottom-0.5 left-1/2 -translate-x-1/2 h-1.5 ${
                          isActive ? 'w-4 bg-[#E95420]' : 'w-1.5 bg-white/70'
                        }`
                  }`}
                />
              )}

              {/* App Icon Button */}
              <button
                onClick={() => onAppClick(appId)}
                className={`flex items-center justify-center rounded-xl transition-all duration-150 relative ${
                  isActive
                    ? 'bg-white/20 shadow-md scale-105'
                    : 'hover:bg-white/15 active:scale-95'
                }`}
                style={{ width: iconSize, height: iconSize }}
                title={meta.name}
              >
                {renderAppIcon(meta.icon, 'w-6 h-6')}
              </button>

              {/* Hover Tooltip */}
              {hoveredApp === appId && (
                <div
                  className={`absolute z-[9999] pointer-events-none px-2.5 py-1 bg-[#1E1E1E]/95 backdrop-blur-md border border-white/10 rounded-md text-xs font-medium text-white shadow-lg whitespace-nowrap ${
                    isLeft ? 'left-16 top-1/2 -translate-y-1/2' : 'bottom-16 left-1/2 -translate-x-1/2'
                  }`}
                >
                  {meta.name}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Bottom "Show Applications" 9-dot Grid Icon */}
      <div
        className="relative flex items-center justify-center"
        onMouseEnter={() => setHoveredApp('show-apps')}
        onMouseLeave={() => setHoveredApp(null)}
      >
        <button
          onClick={onToggleAppGrid}
          className={`flex items-center justify-center rounded-xl transition-all ${
            isAppGridOpen ? 'bg-[#E95420] text-white shadow-md' : 'hover:bg-white/15 text-neutral-300'
          }`}
          style={{ width: iconSize, height: iconSize }}
          title="Show Applications"
        >
          <Grid className="w-6 h-6" />
        </button>

        {hoveredApp === 'show-apps' && (
          <div
            className={`absolute z-[9999] pointer-events-none px-2.5 py-1 bg-[#1E1E1E]/95 backdrop-blur-md border border-white/10 rounded-md text-xs font-medium text-white shadow-lg whitespace-nowrap ${
              isLeft ? 'left-16 top-1/2 -translate-y-1/2' : 'bottom-16 left-1/2 -translate-x-1/2'
            }`}
          >
            Show Applications
          </div>
        )}
      </div>
    </div>
  );
};
