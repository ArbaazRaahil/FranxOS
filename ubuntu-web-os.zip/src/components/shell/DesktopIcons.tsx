/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Home, Trash2, FileText, Folder, Image as ImageIcon } from 'lucide-react';
import { mockFS } from '../../services/mockFileSystem';
import { FileItem } from '../../types/os';

interface DesktopIconsProps {
  onOpenFile: (file: FileItem) => void;
  onOpenFolder: (path: string) => void;
  onOpenTrash: () => void;
}

export const DesktopIcons: React.FC<DesktopIconsProps> = ({
  onOpenFile,
  onOpenFolder,
  onOpenTrash,
}) => {
  const [desktopFiles, setDesktopFiles] = useState<FileItem[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const loadDesktopFiles = () => {
    setDesktopFiles(mockFS.getDirectoryContents('/home/ubuntu/Desktop'));
  };

  useEffect(() => {
    loadDesktopFiles();
    const unsub = mockFS.subscribe(loadDesktopFiles);
    return () => unsub();
  }, []);

  const getIcon = (item: FileItem) => {
    if (item.type === 'folder') {
      return <Folder className="w-10 h-10 text-[#4a90d9] fill-[#4a90d9]/30 drop-shadow-md" />;
    }
    const ext = item.extension?.toLowerCase();
    if (ext === 'svg' || ext === 'png' || ext === 'jpg') {
      return <ImageIcon className="w-10 h-10 text-emerald-400 drop-shadow-md" />;
    }
    return <FileText className="w-10 h-10 text-neutral-200 drop-shadow-md" />;
  };

  return (
    <div
      onClick={() => setSelectedId(null)}
      className="absolute top-10 left-20 bottom-4 right-4 flex flex-col flex-wrap gap-4 items-start content-start pointer-events-auto select-none"
    >
      {/* Home shortcut */}
      <div
        onClick={(e) => {
          e.stopPropagation();
          setSelectedId('home');
        }}
        onDoubleClick={() => onOpenFolder('/home/ubuntu')}
        className={`w-24 p-2 rounded-xl flex flex-col items-center cursor-pointer transition-all ${
          selectedId === 'home'
            ? 'bg-[#E95420]/30 border border-[#E95420]'
            : 'hover:bg-black/25 border border-transparent'
        }`}
      >
        <Home className="w-10 h-10 text-[#E95420] fill-[#E95420]/20 drop-shadow-md" />
        <span className="text-xs font-semibold text-white drop-shadow-md mt-1 text-center truncate w-full px-1">
          Home
        </span>
      </div>

      {/* Trash shortcut */}
      <div
        onClick={(e) => {
          e.stopPropagation();
          setSelectedId('trash');
        }}
        onDoubleClick={onOpenTrash}
        className={`w-24 p-2 rounded-xl flex flex-col items-center cursor-pointer transition-all ${
          selectedId === 'trash'
            ? 'bg-[#E95420]/30 border border-[#E95420]'
            : 'hover:bg-black/25 border border-transparent'
        }`}
      >
        <Trash2 className="w-10 h-10 text-neutral-300 drop-shadow-md" />
        <span className="text-xs font-semibold text-white drop-shadow-md mt-1 text-center truncate w-full px-1">
          Trash
        </span>
      </div>

      {/* Desktop items */}
      {desktopFiles.map((file) => {
        const isSelected = selectedId === file.id;
        return (
          <div
            key={file.id}
            onClick={(e) => {
              e.stopPropagation();
              setSelectedId(file.id);
            }}
            onDoubleClick={() => {
              if (file.type === 'folder') {
                onOpenFolder(file.path);
              } else {
                onOpenFile(file);
              }
            }}
            className={`w-24 p-2 rounded-xl flex flex-col items-center cursor-pointer transition-all ${
              isSelected
                ? 'bg-[#E95420]/30 border border-[#E95420]'
                : 'hover:bg-black/25 border border-transparent'
            }`}
          >
            {getIcon(file)}
            <span className="text-xs font-semibold text-white drop-shadow-md mt-1 text-center truncate w-full px-1">
              {file.name}
            </span>
          </div>
        );
      })}
    </div>
  );
};
