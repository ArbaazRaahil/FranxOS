/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Power, RotateCcw, Moon, X } from 'lucide-react';

interface PowerDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onRestart: () => void;
  onPowerOff: () => void;
}

export const PowerDialog: React.FC<PowerDialogProps> = ({
  isOpen,
  onClose,
  onRestart,
  onPowerOff,
}) => {
  if (!isOpen) return null;

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-[99999] bg-black/70 backdrop-blur-xl flex items-center justify-center p-4 select-none"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm bg-[#252526]/95 border border-white/10 rounded-2xl p-6 text-white shadow-2xl text-center space-y-6"
      >
        <div className="w-14 h-14 rounded-full bg-red-500/20 text-red-500 flex items-center justify-center mx-auto">
          <Power className="w-7 h-7" />
        </div>

        <div>
          <h3 className="text-lg font-bold">Power Off / Restart</h3>
          <p className="text-xs text-neutral-400 mt-1">
            Choose an action for your Ubuntu session.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <button
            onClick={onClose}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 flex flex-col items-center gap-2 text-xs font-semibold"
          >
            <Moon className="w-5 h-5 text-neutral-300" />
            <span>Suspend</span>
          </button>

          <button
            onClick={onRestart}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 flex flex-col items-center gap-2 text-xs font-semibold"
          >
            <RotateCcw className="w-5 h-5 text-blue-400" />
            <span>Restart</span>
          </button>

          <button
            onClick={onPowerOff}
            className="p-3 rounded-xl bg-red-600/30 hover:bg-red-600 border border-red-500/50 flex flex-col items-center gap-2 text-xs font-semibold text-red-200 hover:text-white"
          >
            <Power className="w-5 h-5 text-red-400 group-hover:text-white" />
            <span>Power Off</span>
          </button>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2 bg-neutral-800 hover:bg-neutral-700 rounded-xl text-xs font-semibold text-neutral-300"
        >
          Cancel
        </button>
      </div>
    </div>
  );
};
