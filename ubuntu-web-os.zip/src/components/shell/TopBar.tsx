/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Wifi,
  WifiOff,
  Volume2,
  VolumeX,
  Battery,
  Moon,
  Sun,
  Eye,
  Power,
  Lock,
  Settings as SettingsIcon,
  ChevronRight,
  Bell,
  Calendar as CalendarIcon,
  Sliders,
} from 'lucide-react';
import { SystemSettings, WindowInstance } from '../../types/os';
import { APPS_REGISTRY } from '../../data/appsData';

interface TopBarProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  activeWindow: WindowInstance | null;
  onToggleActivities: () => void;
  isActivitiesOpen: boolean;
  onLockScreen: () => void;
  onOpenPowerDialog: () => void;
  onLaunchApp: (appId: string) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  settings,
  onUpdateSettings,
  activeWindow,
  onToggleActivities,
  isActivitiesOpen,
  onLockScreen,
  onOpenPowerDialog,
  onLaunchApp,
}) => {
  const [timeStr, setTimeStr] = useState('');
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [isQuickSettingsOpen, setIsQuickSettingsOpen] = useState(false);

  const calRef = useRef<HTMLDivElement>(null);
  const quickRef = useRef<HTMLDivElement>(null);

  // Update clock every second
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const options: Intl.DateTimeFormatOptions = {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: false,
      };
      setTimeStr(now.toLocaleDateString('en-US', options).replace(/,/g, ''));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (calRef.current && !calRef.current.contains(e.target as Node)) {
        setIsCalendarOpen(false);
      }
      if (quickRef.current && !quickRef.current.contains(e.target as Node)) {
        setIsQuickSettingsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const activeAppMeta = activeWindow ? APPS_REGISTRY[activeWindow.appId] : null;

  return (
    <div className="h-7 bg-[#111111]/90 backdrop-blur-md text-white text-xs flex items-center justify-between px-3 z-[9990] select-none border-b border-black/40">
      {/* Zone 1: Activities & Active App Title */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleActivities}
          className={`px-2.5 py-0.5 rounded-full font-semibold transition-all ${
            isActivitiesOpen
              ? 'bg-[#E95420] text-white shadow-xs'
              : 'hover:bg-white/15 text-neutral-200'
          }`}
        >
          Activities
        </button>

        {activeAppMeta && !isActivitiesOpen && (
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded hover:bg-white/10 cursor-pointer">
            <span className="font-semibold text-neutral-100">{activeAppMeta.name}</span>
          </div>
        )}
      </div>

      {/* Zone 2: Clock & Calendar Trigger */}
      <div className="relative" ref={calRef}>
        <button
          onClick={() => {
            setIsCalendarOpen(!isCalendarOpen);
            setIsQuickSettingsOpen(false);
          }}
          className={`px-3 py-0.5 rounded-full font-medium transition-colors ${
            isCalendarOpen ? 'bg-white/20' : 'hover:bg-white/10'
          }`}
        >
          <span>{timeStr || 'Wed Nov 4 10:00'}</span>
        </button>

        {/* GNOME Calendar Dropdown Popover */}
        {isCalendarOpen && (
          <div className="absolute left-1/2 -translate-x-1/2 top-8 w-80 bg-[#252526]/95 backdrop-blur-xl border border-white/10 rounded-2xl p-4 gnome-menu-shadow text-neutral-200 z-[9999]">
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
              <div>
                <div className="text-base font-bold text-white">
                  {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                </div>
                <div className="text-[11px] text-neutral-400">
                  {new Date().toLocaleDateString('en-US', { weekday: 'long', day: 'numeric' })}
                </div>
              </div>
              <button
                onClick={() => {
                  onLaunchApp('calendar');
                  setIsCalendarOpen(false);
                }}
                className="px-2.5 py-1 bg-[#E95420] hover:bg-[#d84a1b] text-white rounded-lg text-xs font-semibold"
              >
                Open Calendar
              </button>
            </div>

            {/* Mini Calendar View */}
            <div className="grid grid-cols-7 gap-1 text-center text-xs mb-3">
              {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
                <div key={i} className="text-neutral-500 font-bold py-1">
                  {d}
                </div>
              ))}
              {Array.from({ length: 30 }).map((_, i) => {
                const day = i + 1;
                const isToday = day === 4;
                return (
                  <div
                    key={day}
                    className={`py-1 rounded-md text-xs font-medium ${
                      isToday
                        ? 'bg-[#E95420] text-white font-bold'
                        : 'hover:bg-white/10 text-neutral-300'
                    }`}
                  >
                    {day}
                  </div>
                );
              })}
            </div>

            {/* Notifications Header */}
            <div className="border-t border-white/10 pt-3">
              <div className="flex items-center justify-between text-xs font-semibold mb-2 text-neutral-300">
                <span className="flex items-center gap-1.5">
                  <Bell className="w-3.5 h-3.5 text-[#E95420]" />
                  <span>Notifications</span>
                </span>
                <span className="text-[10px] text-neutral-500">Do Not Disturb: Off</span>
              </div>
              <div className="p-2.5 bg-black/30 rounded-xl border border-white/5 text-xs">
                <div className="font-semibold text-white">Ubuntu 24.04 LTS Active</div>
                <div className="text-[11px] text-neutral-400 mt-0.5">
                  All systems operational. Yaru desktop compositor running smoothly.
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Zone 3: Quick Settings Indicators Pill */}
      <div className="relative" ref={quickRef}>
        <button
          onClick={() => {
            setIsQuickSettingsOpen(!isQuickSettingsOpen);
            setIsCalendarOpen(false);
          }}
          className={`flex items-center gap-2 px-2.5 py-0.5 rounded-full transition-colors ${
            isQuickSettingsOpen ? 'bg-white/20' : 'hover:bg-white/10'
          }`}
        >
          {settings.wifiEnabled ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5 text-neutral-400" />}
          {settings.isMuted || settings.volume === 0 ? (
            <VolumeX className="w-3.5 h-3.5 text-neutral-400" />
          ) : (
            <Volume2 className="w-3.5 h-3.5" />
          )}
          <Battery className="w-3.5 h-3.5" />
        </button>

        {/* GNOME Quick Settings Menu */}
        {isQuickSettingsOpen && (
          <div className="absolute right-0 top-8 w-72 bg-[#252526]/95 backdrop-blur-xl border border-white/10 rounded-2xl p-4 gnome-menu-shadow text-neutral-200 z-[9999] space-y-4">
            {/* Quick Toggle Tiles */}
            <div className="grid grid-cols-2 gap-2">
              {/* Wi-Fi Tile */}
              <button
                onClick={() => onUpdateSettings({ wifiEnabled: !settings.wifiEnabled })}
                className={`p-2.5 rounded-xl flex items-center gap-2.5 text-left transition-colors border ${
                  settings.wifiEnabled
                    ? 'bg-[#E95420] text-white border-transparent'
                    : 'bg-white/5 border-white/10 hover:bg-white/10 text-neutral-300'
                }`}
              >
                <Wifi className="w-4 h-4 shrink-0" />
                <div className="truncate">
                  <div className="text-xs font-semibold">Wi-Fi</div>
                  <div className="text-[10px] opacity-80">{settings.wifiEnabled ? 'Home-Network' : 'Off'}</div>
                </div>
              </button>

              {/* Dark Style Tile */}
              <button
                onClick={() => onUpdateSettings({ theme: settings.theme === 'dark' ? 'light' : 'dark' })}
                className={`p-2.5 rounded-xl flex items-center gap-2.5 text-left transition-colors border ${
                  settings.theme === 'dark'
                    ? 'bg-[#E95420] text-white border-transparent'
                    : 'bg-white/5 border-white/10 hover:bg-white/10 text-neutral-300'
                }`}
              >
                <Moon className="w-4 h-4 shrink-0" />
                <div className="truncate">
                  <div className="text-xs font-semibold">Dark Style</div>
                  <div className="text-[10px] opacity-80">{settings.theme === 'dark' ? 'On' : 'Off'}</div>
                </div>
              </button>

              {/* Night Light Tile */}
              <button
                onClick={() => onUpdateSettings({ nightLight: !settings.nightLight })}
                className={`p-2.5 rounded-xl flex items-center gap-2.5 text-left transition-colors border ${
                  settings.nightLight
                    ? 'bg-[#E95420] text-white border-transparent'
                    : 'bg-white/5 border-white/10 hover:bg-white/10 text-neutral-300'
                }`}
              >
                <Eye className="w-4 h-4 shrink-0" />
                <div className="truncate">
                  <div className="text-xs font-semibold">Night Light</div>
                  <div className="text-[10px] opacity-80">{settings.nightLight ? 'Active' : 'Off'}</div>
                </div>
              </button>

              {/* Bluetooth Tile */}
              <button
                onClick={() => onUpdateSettings({ bluetoothEnabled: !settings.bluetoothEnabled })}
                className={`p-2.5 rounded-xl flex items-center gap-2.5 text-left transition-colors border ${
                  settings.bluetoothEnabled
                    ? 'bg-[#E95420] text-white border-transparent'
                    : 'bg-white/5 border-white/10 hover:bg-white/10 text-neutral-300'
                }`}
              >
                <Sliders className="w-4 h-4 shrink-0" />
                <div className="truncate">
                  <div className="text-xs font-semibold">Bluetooth</div>
                  <div className="text-[10px] opacity-80">{settings.bluetoothEnabled ? 'Active' : 'Off'}</div>
                </div>
              </button>
            </div>

            {/* Volume Slider */}
            <div className="space-y-1">
              <div className="flex items-center gap-2.5 bg-white/5 p-2 rounded-xl">
                <button
                  onClick={() => onUpdateSettings({ isMuted: !settings.isMuted })}
                  className="text-neutral-400 hover:text-white"
                >
                  {settings.isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={settings.isMuted ? 0 : settings.volume}
                  onChange={(e) => onUpdateSettings({ volume: Number(e.target.value), isMuted: false })}
                  className="w-full accent-[#E95420] h-1.5 bg-neutral-700 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>

            {/* Brightness Slider */}
            <div className="space-y-1">
              <div className="flex items-center gap-2.5 bg-white/5 p-2 rounded-xl">
                <Sun className="w-4 h-4 text-neutral-400" />
                <input
                  type="range"
                  min="30"
                  max="100"
                  value={settings.brightness}
                  onChange={(e) => onUpdateSettings({ brightness: Number(e.target.value) })}
                  className="w-full accent-[#E95420] h-1.5 bg-neutral-700 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>

            {/* Bottom Actions: Settings, Lock, Power */}
            <div className="flex items-center justify-between pt-2 border-t border-white/10">
              <button
                onClick={() => {
                  onLaunchApp('settings');
                  setIsQuickSettingsOpen(false);
                }}
                className="p-2 rounded-full hover:bg-white/10 text-neutral-300 hover:text-white"
                title="Settings"
              >
                <SettingsIcon className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  onLockScreen();
                  setIsQuickSettingsOpen(false);
                }}
                className="p-2 rounded-full hover:bg-white/10 text-neutral-300 hover:text-white"
                title="Lock Screen"
              >
                <Lock className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  onOpenPowerDialog();
                  setIsQuickSettingsOpen(false);
                }}
                className="p-2 rounded-full hover:bg-red-500/20 text-neutral-300 hover:text-red-400"
                title="Power Off / Log Out"
              >
                <Power className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
