/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  X,
  Terminal,
  Folder,
  Globe,
  FileText,
  Calculator,
  Calendar,
  Music,
  ShoppingBag,
  Settings,
  Image as ImageIcon,
  Bomb,
  File,
} from 'lucide-react';
import { AppId, WindowInstance, FileItem } from '../../types/os';
import { APPS_REGISTRY } from '../../data/appsData';
import { mockFS } from '../../services/mockFileSystem';

interface ActivitiesOverviewProps {
  isOpen: boolean;
  onClose: () => void;
  openWindows: WindowInstance[];
  onSelectWindow: (winId: string) => void;
  onCloseWindow: (winId: string) => void;
  onLaunchApp: (appId: AppId, params?: any) => void;
  isAppGridMode?: boolean;
}

export const ActivitiesOverview: React.FC<ActivitiesOverviewProps> = ({
  isOpen,
  onClose,
  openWindows,
  onSelectWindow,
  onCloseWindow,
  onLaunchApp,
  isAppGridMode = false,
}) => {
  const [search, setSearch] = useState('');
  const [matchingFiles, setMatchingFiles] = useState<FileItem[]>([]);
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => searchInputRef.current?.focus(), 50);
      setSearch('');
    }
  }, [isOpen]);

  useEffect(() => {
    if (search.trim()) {
      setMatchingFiles(mockFS.search(search).slice(0, 5));
    } else {
      setMatchingFiles([]);
    }
  }, [search]);

  if (!isOpen) return null;

  // Filter apps by search
  const filteredApps = Object.values(APPS_REGISTRY).filter((app) => {
    if (!search.trim()) return true;
    return (
      app.name.toLowerCase().includes(search.toLowerCase()) ||
      app.description.toLowerCase().includes(search.toLowerCase()) ||
      app.category.toLowerCase().includes(search.toLowerCase())
    );
  });

  const renderIcon = (icon: string, className = 'w-8 h-8') => {
    switch (icon) {
      case 'terminal':
        return <Terminal className={`${className} text-emerald-400`} />;
      case 'folder':
        return <Folder className={`${className} text-[#4a90d9] fill-[#4a90d9]/30`} />;
      case 'globe':
        return <Globe className={`${className} text-[#E95420]`} />;
      case 'file-text':
        return <FileText className={`${className} text-amber-400`} />;
      case 'calculator':
        return <Calculator className={`${className} text-neutral-200`} />;
      case 'calendar':
        return <Calendar className={`${className} text-red-400`} />;
      case 'music':
        return <Music className={`${className} text-purple-400`} />;
      case 'shopping-bag':
        return <ShoppingBag className={`${className} text-[#E95420]`} />;
      case 'settings':
        return <Settings className={`${className} text-neutral-300`} />;
      case 'image':
        return <ImageIcon className={`${className} text-cyan-400`} />;
      case 'bomb':
        return <Bomb className={`${className} text-red-500`} />;
      default:
        return <File className={className} />;
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 top-7 z-[9988] bg-black/75 backdrop-blur-2xl flex flex-col items-center pt-6 px-8 select-none text-white overflow-y-auto"
    >
      {/* Top Search Input */}
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg relative mb-8"
      >
        <Search className="w-5 h-5 text-neutral-400 absolute left-4 top-3" />
        <input
          ref={searchInputRef}
          type="text"
          placeholder="Type to search applications, files, settings..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-12 pr-10 py-2.5 rounded-full bg-white/10 border border-white/20 text-white placeholder-neutral-400 text-sm outline-none focus:bg-white/15 focus:border-[#E95420] focus:ring-2 focus:ring-[#E95420]/30 transition-all shadow-lg"
        />
        {search && (
          <button
            onClick={() => setSearch('')}
            className="absolute right-4 top-3 text-neutral-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* If Searching: Show Unified Search Results */}
      {search.trim() ? (
        <div
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-3xl space-y-6"
        >
          {/* Apps result */}
          <div>
            <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-3">
              Applications ({filteredApps.length})
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {filteredApps.map((app) => (
                <div
                  key={app.id}
                  onClick={() => {
                    onLaunchApp(app.id);
                    onClose();
                  }}
                  className="p-3 bg-white/5 hover:bg-white/15 border border-white/10 rounded-xl cursor-pointer flex flex-col items-center text-center gap-2 transition-all hover:scale-105"
                >
                  {renderIcon(app.icon, 'w-10 h-10')}
                  <span className="text-xs font-semibold">{app.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Files result */}
          {matchingFiles.length > 0 && (
            <div>
              <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-3">
                Files & Documents ({matchingFiles.length})
              </h4>
              <div className="space-y-1.5">
                {matchingFiles.map((file) => (
                  <div
                    key={file.id}
                    onClick={() => {
                      if (file.type === 'folder') {
                        onLaunchApp('files', { path: file.path });
                      } else {
                        onLaunchApp('editor', { file });
                      }
                      onClose();
                    }}
                    className="p-2.5 bg-white/5 hover:bg-white/15 border border-white/10 rounded-xl cursor-pointer flex items-center justify-between transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      {file.type === 'folder' ? (
                        <Folder className="w-5 h-5 text-[#4a90d9]" />
                      ) : (
                        <FileText className="w-5 h-5 text-amber-400" />
                      )}
                      <div>
                        <div className="text-xs font-semibold">{file.name}</div>
                        <div className="text-[10px] text-neutral-400">{file.path}</div>
                      </div>
                    </div>
                    <span className="text-[10px] text-neutral-400">{file.updatedAt}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Standard GNOME Activities: Open Windows Workspace + App Grid */
        <div
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-5xl flex flex-col items-center space-y-10"
        >
          {/* Open Windows Workspace Grid (Expose Mode) */}
          {openWindows.length > 0 && (
            <div className="w-full">
              <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-4 text-center">
                Active Workspace Windows ({openWindows.length})
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 justify-center">
                {openWindows.map((win) => {
                  const meta = APPS_REGISTRY[win.appId];
                  return (
                    <div
                      key={win.id}
                      onClick={() => {
                        onSelectWindow(win.id);
                        onClose();
                      }}
                      className="group relative bg-[#222222]/90 hover:bg-[#2b2b2b] border border-white/15 hover:border-[#E95420] rounded-2xl p-3 cursor-pointer shadow-xl transition-all duration-200 hover:scale-102 flex flex-col h-48"
                    >
                      {/* Window header preview */}
                      <div className="flex items-center justify-between pb-2 border-b border-white/10 mb-2">
                        <div className="flex items-center gap-2 truncate">
                          {meta && renderIcon(meta.icon, 'w-4 h-4')}
                          <span className="text-xs font-semibold truncate text-neutral-200">
                            {win.title}
                          </span>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onCloseWindow(win.id);
                          }}
                          className="w-5 h-5 rounded-full bg-white/10 hover:bg-red-500 text-white flex items-center justify-center transition-colors"
                          title="Close Window"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Mock thumbnail viewport */}
                      <div className="flex-1 rounded-lg bg-neutral-900/80 border border-white/5 flex items-center justify-center p-3 text-neutral-500 overflow-hidden text-[11px]">
                        <div className="text-center">
                          <div className="mb-1">{meta && renderIcon(meta.icon, 'w-8 h-8 mx-auto')}</div>
                          <span className="opacity-70 font-mono">Running: {win.appId}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Full App Grid */}
          <div className="w-full pt-4 border-t border-white/10">
            <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-6 text-center">
              All Applications
            </h4>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-6 justify-items-center">
              {Object.values(APPS_REGISTRY).map((app) => (
                <div
                  key={app.id}
                  onClick={() => {
                    onLaunchApp(app.id);
                    onClose();
                  }}
                  className="flex flex-col items-center gap-2 group cursor-pointer p-2 rounded-xl hover:bg-white/10 transition-all hover:scale-105 text-center w-28"
                >
                  <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:border-[#E95420]/80 group-hover:bg-white/10 transition-colors shadow-md">
                    {renderIcon(app.icon, 'w-8 h-8')}
                  </div>
                  <span className="text-xs font-medium text-neutral-200 group-hover:text-white truncate w-full">
                    {app.name}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
