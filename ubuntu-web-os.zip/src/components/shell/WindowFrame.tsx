/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect } from 'react';
import { Minus, Square, Copy, X } from 'lucide-react';
import { WindowInstance } from '../../types/os';
import { soundService } from '../../services/soundEffects';

interface WindowFrameProps {
  window: WindowInstance;
  isActive: boolean;
  onFocus: () => void;
  onClose: () => void;
  onMinimize: () => void;
  onToggleMaximize: () => void;
  onUpdateBounds: (bounds: { x: number; y: number; width: number; height: number }) => void;
  onSnap: (side: 'left' | 'right' | null) => void;
  children: React.ReactNode;
}

export const WindowFrame: React.FC<WindowFrameProps> = ({
  window: win,
  isActive,
  onFocus,
  onClose,
  onMinimize,
  onToggleMaximize,
  onUpdateBounds,
  onSnap,
  children,
}) => {
  const windowRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [snapPreview, setSnapPreview] = useState<'left' | 'right' | 'top' | null>(null);

  // Dragging handler
  const handleTitleMouseDown = (e: React.MouseEvent) => {
    if (win.isMaximized) return; // Can't drag maximized directly
    if ((e.target as HTMLElement).closest('.window-control-btn')) return;

    onFocus();
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - win.x,
      y: e.clientY - win.y,
    });
  };

  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: MouseEvent) => {
      let nextX = e.clientX - dragOffset.x;
      let nextY = e.clientY - dragOffset.y;

      // Restrict top boundary (TopBar is 28px)
      nextY = Math.max(28, nextY);

      // Snap preview detection
      if (e.clientX < 15) {
        setSnapPreview('left');
      } else if (e.clientX > window.innerWidth - 15) {
        setSnapPreview('right');
      } else if (e.clientY < 35) {
        setSnapPreview('top');
      } else {
        setSnapPreview(null);
      }

      onUpdateBounds({
        x: nextX,
        y: nextY,
        width: win.width,
        height: win.height,
      });
    };

    const handleMouseUp = (e: MouseEvent) => {
      setIsDragging(false);

      if (e.clientX < 15) {
        onSnap('left');
      } else if (e.clientX > window.innerWidth - 15) {
        onSnap('right');
      } else if (e.clientY < 35) {
        onToggleMaximize();
      }

      setSnapPreview(null);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragOffset, win.width, win.height, onUpdateBounds, onSnap, onToggleMaximize]);

  // Resizing logic for 8 directions
  const handleResizeMouseDown = (direction: string, e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    onFocus();

    const startX = e.clientX;
    const startY = e.clientY;
    const startBounds = { x: win.x, y: win.y, width: win.width, height: win.height };

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = moveEvent.clientX - startX;
      const deltaY = moveEvent.clientY - startY;

      let newWidth = startBounds.width;
      let newHeight = startBounds.height;
      let newX = startBounds.x;
      let newY = startBounds.y;

      if (direction.includes('e')) {
        newWidth = Math.max(340, startBounds.width + deltaX);
      }
      if (direction.includes('s')) {
        newHeight = Math.max(240, startBounds.height + deltaY);
      }
      if (direction.includes('w')) {
        const potentialWidth = startBounds.width - deltaX;
        if (potentialWidth >= 340) {
          newWidth = potentialWidth;
          newX = startBounds.x + deltaX;
        }
      }
      if (direction.includes('n')) {
        const potentialHeight = startBounds.height - deltaY;
        if (potentialHeight >= 240) {
          newHeight = potentialHeight;
          newY = Math.max(28, startBounds.y + deltaY);
        }
      }

      onUpdateBounds({ x: newX, y: newY, width: newWidth, height: newHeight });
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  if (win.isMinimized) return null;

  // Window geometry styling
  const windowStyle: React.CSSProperties = win.isMaximized
    ? {
        position: 'fixed',
        left: 64, // beside left dock
        top: 28, // below topbar
        width: 'calc(100vw - 64px)',
        height: 'calc(100vh - 28px)',
        zIndex: win.zIndex,
        borderRadius: 0,
      }
    : win.isSnapped === 'left'
    ? {
        position: 'fixed',
        left: 64,
        top: 28,
        width: 'calc((100vw - 64px) / 2)',
        height: 'calc(100vh - 28px)',
        zIndex: win.zIndex,
        borderRadius: 0,
      }
    : win.isSnapped === 'right'
    ? {
        position: 'fixed',
        left: 'calc(64px + (100vw - 64px) / 2)',
        top: 28,
        width: 'calc((100vw - 64px) / 2)',
        height: 'calc(100vh - 28px)',
        zIndex: win.zIndex,
        borderRadius: 0,
      }
    : {
        position: 'fixed',
        left: win.x,
        top: win.y,
        width: win.width,
        height: win.height,
        zIndex: win.zIndex,
      };

  return (
    <>
      {/* Snap preview phantom box */}
      {snapPreview && (
        <div
          className={`fixed pointer-events-none z-[9985] bg-[#E95420]/20 border-2 border-[#E95420] rounded-xl transition-all duration-100 ${
            snapPreview === 'left'
              ? 'left-16 top-7 bottom-0 w-1/2'
              : snapPreview === 'right'
              ? 'right-0 top-7 bottom-0 w-1/2'
              : 'left-16 right-0 top-7 bottom-0'
          }`}
        />
      )}

      {/* Main Window Frame */}
      <div
        ref={windowRef}
        onClick={onFocus}
        style={windowStyle}
        className={`flex flex-col bg-neutral-100 dark:bg-[#1E1E1E] overflow-hidden transition-shadow select-none ${
          win.isMaximized || win.isSnapped ? 'rounded-none' : 'rounded-t-xl rounded-b-lg'
        } ${
          isActive
            ? 'gnome-window-shadow-focused ring-1 ring-white/10'
            : 'gnome-window-shadow opacity-95'
        }`}
      >
        {/* Yaru Window Header Titlebar */}
        <div
          onMouseDown={handleTitleMouseDown}
          onDoubleClick={onToggleMaximize}
          className={`h-9 px-3.5 flex items-center justify-between cursor-default shrink-0 border-b select-none transition-colors ${
            isActive
              ? 'bg-[#2E2E2E] text-white border-black/40'
              : 'bg-[#242424] text-neutral-400 border-black/30'
          }`}
        >
          {/* Left Title */}
          <div className="flex items-center gap-2 overflow-hidden mr-2">
            <span className="text-xs font-semibold truncate tracking-wide">
              {win.title}
            </span>
          </div>

          {/* Right Yaru Window Controls (Minimize, Maximize, Close) */}
          <div className="flex items-center gap-2 window-control-btn shrink-0">
            {/* Minimize */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onMinimize();
              }}
              className="w-5 h-5 rounded-full bg-neutral-600/60 hover:bg-neutral-500 text-neutral-200 flex items-center justify-center transition-colors"
              title="Minimize"
            >
              <Minus className="w-3 h-3 stroke-[3]" />
            </button>

            {/* Maximize / Restore */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleMaximize();
              }}
              className="w-5 h-5 rounded-full bg-neutral-600/60 hover:bg-neutral-500 text-neutral-200 flex items-center justify-center transition-colors"
              title={win.isMaximized ? 'Restore' : 'Maximize'}
            >
              {win.isMaximized ? (
                <Copy className="w-2.5 h-2.5 stroke-[2]" />
              ) : (
                <Square className="w-2.5 h-2.5 stroke-[2]" />
              )}
            </button>

            {/* Close */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                soundService.playWindowClose();
                onClose();
              }}
              className="w-5 h-5 rounded-full bg-[#E95420]/80 hover:bg-[#E95420] text-white flex items-center justify-center transition-colors shadow-xs"
              title="Close"
            >
              <X className="w-3 h-3 stroke-[3]" />
            </button>
          </div>
        </div>

        {/* Client Window Content Area */}
        <div className="flex-1 overflow-hidden relative">{children}</div>

        {/* 8 Resize Handles (only when not maximized) */}
        {!win.isMaximized && !win.isSnapped && (
          <>
            <div
              onMouseDown={(e) => handleResizeMouseDown('n', e)}
              className="absolute top-0 left-2 right-2 h-1.5 cursor-n-resize"
            />
            <div
              onMouseDown={(e) => handleResizeMouseDown('s', e)}
              className="absolute bottom-0 left-2 right-2 h-1.5 cursor-s-resize"
            />
            <div
              onMouseDown={(e) => handleResizeMouseDown('w', e)}
              className="absolute left-0 top-2 bottom-2 w-1.5 cursor-w-resize"
            />
            <div
              onMouseDown={(e) => handleResizeMouseDown('e', e)}
              className="absolute right-0 top-2 bottom-2 w-1.5 cursor-e-resize"
            />
            <div
              onMouseDown={(e) => handleResizeMouseDown('nw', e)}
              className="absolute top-0 left-0 w-3 h-3 cursor-nw-resize"
            />
            <div
              onMouseDown={(e) => handleResizeMouseDown('ne', e)}
              className="absolute top-0 right-0 w-3 h-3 cursor-ne-resize"
            />
            <div
              onMouseDown={(e) => handleResizeMouseDown('sw', e)}
              className="absolute bottom-0 left-0 w-3 h-3 cursor-sw-resize"
            />
            <div
              onMouseDown={(e) => handleResizeMouseDown('se', e)}
              className="absolute bottom-0 right-0 w-3 h-3 cursor-se-resize"
            />
          </>
        )}
      </div>
    </>
  );
};
