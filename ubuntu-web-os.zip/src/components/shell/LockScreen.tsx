/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ArrowRight, User } from 'lucide-react';

interface LockScreenProps {
  isLocked: boolean;
  onUnlock: () => void;
  wallpaper: string;
}

export const LockScreen: React.FC<LockScreenProps> = ({ isLocked, onUnlock, wallpaper }) => {
  const [timeStr, setTimeStr] = useState('');
  const [dateStr, setDateStr] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false })
      );
      setDateStr(
        now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  if (!isLocked) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUnlock();
    setPassword('');
  };

  return (
    <div
      className="fixed inset-0 z-[99999] flex flex-col justify-between items-center text-white p-12 select-none overflow-hidden"
      style={{ background: wallpaper }}
    >
      {/* Background Blur Overlay */}
      <div className="absolute inset-0 bg-black/45 backdrop-blur-3xl" />

      {/* Top Clock */}
      <div className="relative z-10 text-center mt-12">
        <h1 className="text-7xl sm:text-8xl font-light tracking-tight text-white/95 font-sans">
          {timeStr || '10:00'}
        </h1>
        <p className="text-lg sm:text-xl text-white/80 font-normal mt-2">{dateStr}</p>
      </div>

      {/* User Login Form */}
      <div className="relative z-10 w-full max-w-xs flex flex-col items-center mb-16">
        <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#E95420] to-[#772953] flex items-center justify-center text-white mb-4 shadow-xl border-2 border-white/20">
          <User className="w-12 h-12" />
        </div>
        <h3 className="text-lg font-bold text-white mb-4">Ubuntu User</h3>

        <form onSubmit={handleSubmit} className="w-full flex items-center gap-2">
          <input
            type="password"
            placeholder="Password (press Enter)"
            autoFocus
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="flex-1 px-4 py-2.5 rounded-full bg-white/15 backdrop-blur-md border border-white/20 text-white placeholder-white/50 text-sm outline-none focus:bg-white/20 focus:border-[#E95420] transition-all"
          />
          <button
            type="submit"
            className="w-10 h-10 rounded-full bg-[#E95420] hover:bg-[#d84a1b] text-white flex items-center justify-center transition-all shadow-md shrink-0"
            title="Log In"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
        </form>
        <p className="text-xs text-white/60 mt-3">Click arrow or press Enter to unlock</p>
      </div>

      {/* Footer */}
      <div className="relative z-10 text-xs text-white/40">
        Ubuntu 24.04 LTS · Linux 6.8.0-31-generic
      </div>
    </div>
  );
};
