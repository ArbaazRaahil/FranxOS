/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Download,
  Check,
  Star,
  Search,
  Sparkles,
  ShieldCheck,
  RotateCw,
  Terminal,
  Calculator,
  Folder,
  Music,
  Globe,
  Bomb,
  Code2,
} from 'lucide-react';

interface AppPackage {
  id: string;
  name: string;
  summary: string;
  icon: string;
  category: string;
  version: string;
  size: string;
  developer: string;
  isInstalled: boolean;
  appId?: string;
}

const INITIAL_PACKAGES: AppPackage[] = [
  {
    id: 'minesweeper',
    name: 'GNOME Mines',
    summary: 'Clear hidden mines from a logic minefield',
    icon: 'bomb',
    category: 'Games',
    version: '40.1',
    size: '14.2 MB',
    developer: 'GNOME Foundation',
    isInstalled: true,
    appId: 'minesweeper',
  },
  {
    id: 'terminal',
    name: 'GNOME Terminal',
    summary: 'The command line shell for Ubuntu Linux',
    icon: 'terminal',
    category: 'System',
    version: '3.52.0',
    size: '8.4 MB',
    developer: 'Canonical Ltd.',
    isInstalled: true,
    appId: 'terminal',
  },
  {
    id: 'firefox',
    name: 'Firefox Web Browser',
    summary: 'Fast, private and open source web browser',
    icon: 'globe',
    category: 'Internet',
    version: '125.0.2',
    size: '180 MB',
    developer: 'Mozilla Foundation',
    isInstalled: true,
    appId: 'browser',
  },
  {
    id: 'calculator',
    name: 'GNOME Calculator',
    summary: 'Solve mathematical equations and scientific problems',
    icon: 'calculator',
    category: 'Utilities',
    version: '46.0',
    size: '5.1 MB',
    developer: 'GNOME Foundation',
    isInstalled: true,
    appId: 'calc',
  },
  {
    id: 'rhythmbox',
    name: 'Rhythmbox Music Player',
    summary: 'Play music and listen to internet radio',
    icon: 'music',
    category: 'Audio & Video',
    version: '3.4.7',
    size: '22 MB',
    developer: 'GNOME Foundation',
    isInstalled: true,
    appId: 'music',
  },
  {
    id: 'vscode',
    name: 'Visual Studio Code',
    summary: 'Code editing redefined with modern language support',
    icon: 'code',
    category: 'Development',
    version: '1.88.1',
    size: '95 MB',
    developer: 'Microsoft / Open Source',
    isInstalled: false,
  },
  {
    id: 'vlc',
    name: 'VLC Media Player',
    summary: 'Multi-platform media player and streaming framework',
    icon: 'video',
    category: 'Audio & Video',
    version: '3.0.20',
    size: '48 MB',
    developer: 'VideoLAN',
    isInstalled: false,
  },
  {
    id: 'gimp',
    name: 'GNU Image Manipulation (GIMP)',
    summary: 'Professional photo retouching and graphic design tool',
    icon: 'image',
    category: 'Graphics',
    version: '2.10.36',
    size: '124 MB',
    developer: 'GIMP Project',
    isInstalled: false,
  },
];

interface SoftwareAppProps {
  onLaunchApp?: (appId: string) => void;
}

export const SoftwareApp: React.FC<SoftwareAppProps> = ({ onLaunchApp }) => {
  const [packages, setPackages] = useState<AppPackage[]>(INITIAL_PACKAGES);
  const [activeTab, setActiveTab] = useState<'explore' | 'installed' | 'updates'>('explore');
  const [search, setSearch] = useState('');
  const [selectedPkg, setSelectedPkg] = useState<AppPackage>(INITIAL_PACKAGES[0]);
  const [installingId, setInstallingId] = useState<string | null>(null);

  const toggleInstall = (pkg: AppPackage) => {
    setInstallingId(pkg.id);
    setTimeout(() => {
      setPackages((prev) =>
        prev.map((p) => (p.id === pkg.id ? { ...p, isInstalled: !p.isInstalled } : p))
      );
      setSelectedPkg((prev) => (prev.id === pkg.id ? { ...prev, isInstalled: !prev.isInstalled } : prev));
      setInstallingId(null);
    }, 1200);
  };

  const filtered = packages.filter((p) => {
    if (activeTab === 'installed') return p.isInstalled;
    if (activeTab === 'updates') return false; // up to date
    if (search.trim()) {
      return (
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.category.toLowerCase().includes(search.toLowerCase())
      );
    }
    return true;
  });

  return (
    <div className="w-full h-full flex flex-col bg-neutral-100 dark:bg-[#1E1E1E] text-neutral-800 dark:text-neutral-200 text-sm overflow-hidden select-none">
      {/* Top Header */}
      <div className="h-12 bg-white dark:bg-[#252526] border-b border-neutral-300 dark:border-neutral-800 px-4 flex items-center justify-between">
        {/* Navigation Tabs */}
        <div className="flex bg-neutral-200 dark:bg-neutral-800 p-0.5 rounded-lg text-xs font-semibold">
          <button
            onClick={() => setActiveTab('explore')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeTab === 'explore'
                ? 'bg-white dark:bg-neutral-700 text-[#E95420] shadow-xs'
                : 'text-neutral-600 dark:text-neutral-400'
            }`}
          >
            Explore
          </button>
          <button
            onClick={() => setActiveTab('installed')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeTab === 'installed'
                ? 'bg-white dark:bg-neutral-700 text-[#E95420] shadow-xs'
                : 'text-neutral-600 dark:text-neutral-400'
            }`}
          >
            Installed ({packages.filter((p) => p.isInstalled).length})
          </button>
          <button
            onClick={() => setActiveTab('updates')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeTab === 'updates'
                ? 'bg-white dark:bg-neutral-700 text-[#E95420] shadow-xs'
                : 'text-neutral-600 dark:text-neutral-400'
            }`}
          >
            Updates
          </button>
        </div>

        {/* Search */}
        <div className="relative w-48">
          <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-2.5" />
          <input
            type="text"
            placeholder="Search software..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-1 text-xs rounded-lg border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 outline-none focus:border-[#E95420]"
          />
        </div>
      </div>

      {/* Main split: Package list & Package detail */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left List */}
        <div className="w-1/2 p-4 overflow-y-auto border-r border-neutral-300 dark:border-neutral-800 space-y-2">
          {activeTab === 'updates' ? (
            <div className="text-center py-16 text-neutral-400">
              <Check className="w-12 h-12 text-emerald-500 mx-auto mb-2" />
              <h4 className="font-bold text-neutral-800 dark:text-neutral-200">Software is up to date</h4>
              <p className="text-xs text-neutral-400 mt-1">Ubuntu 24.04 LTS checked today</p>
            </div>
          ) : (
            filtered.map((pkg) => {
              const isSelected = selectedPkg.id === pkg.id;
              return (
                <div
                  key={pkg.id}
                  onClick={() => setSelectedPkg(pkg)}
                  className={`p-3 rounded-xl cursor-pointer transition-all border flex items-center justify-between ${
                    isSelected
                      ? 'border-[#E95420] bg-white dark:bg-[#252526] shadow-sm'
                      : 'border-transparent bg-white/60 dark:bg-[#252526]/50 hover:bg-white dark:hover:bg-[#252526]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#E95420]/20 to-[#772953]/20 flex items-center justify-center text-[#E95420] shrink-0 font-bold">
                      {pkg.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-semibold text-xs text-neutral-900 dark:text-white">
                        {pkg.name}
                      </h4>
                      <p className="text-[11px] text-neutral-500 truncate max-w-[200px]">
                        {pkg.summary}
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full font-medium bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400">
                    {pkg.category}
                  </span>
                </div>
              );
            })
          )}
        </div>

        {/* Right Detail View */}
        <div className="w-1/2 p-6 bg-white dark:bg-[#181818] overflow-y-auto">
          {selectedPkg && (
            <div className="space-y-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#E95420] to-[#772953] flex items-center justify-center text-white text-2xl font-bold shadow-md">
                    {selectedPkg.name.charAt(0)}
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-neutral-900 dark:text-white">
                      {selectedPkg.name}
                    </h2>
                    <p className="text-xs text-neutral-500">{selectedPkg.developer}</p>
                    <div className="flex items-center gap-1 text-amber-500 mt-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} className="w-3 h-3 fill-current" />
                      ))}
                      <span className="text-[11px] text-neutral-400 ml-1">4.8 / 5</span>
                    </div>
                  </div>
                </div>

                {/* Install / Open / Remove Buttons */}
                <div className="flex gap-2">
                  {selectedPkg.isInstalled && selectedPkg.appId && onLaunchApp && (
                    <button
                      onClick={() => onLaunchApp(selectedPkg.appId!)}
                      className="px-4 py-1.5 bg-[#E95420] text-white rounded-lg text-xs font-semibold hover:bg-[#d84a1b] shadow-xs"
                    >
                      Open
                    </button>
                  )}
                  <button
                    onClick={() => toggleInstall(selectedPkg)}
                    disabled={installingId === selectedPkg.id}
                    className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                      selectedPkg.isInstalled
                        ? 'bg-neutral-200 dark:bg-neutral-800 hover:bg-red-500 hover:text-white text-neutral-700 dark:text-neutral-300'
                        : 'bg-[#E95420] text-white hover:bg-[#d84a1b]'
                    }`}
                  >
                    {installingId === selectedPkg.id ? (
                      <>
                        <RotateCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Working...</span>
                      </>
                    ) : selectedPkg.isInstalled ? (
                      'Installed'
                    ) : (
                      <>
                        <Download className="w-3.5 h-3.5" />
                        <span>Install</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <h4 className="font-bold text-xs uppercase tracking-wider text-neutral-400">About</h4>
                <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                  {selectedPkg.summary}. Packaged using Canonical Snap format for secure sandboxing and automatic background updates on Ubuntu 24.04 LTS.
                </p>
              </div>

              {/* Specs Grid */}
              <div className="grid grid-cols-3 gap-3 p-3 bg-neutral-50 dark:bg-neutral-900 rounded-xl text-center border border-neutral-200 dark:border-neutral-800">
                <div>
                  <div className="text-[10px] text-neutral-400 uppercase">Version</div>
                  <div className="font-semibold text-xs text-neutral-800 dark:text-neutral-200 font-mono mt-0.5">
                    {selectedPkg.version}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-neutral-400 uppercase">Download Size</div>
                  <div className="font-semibold text-xs text-neutral-800 dark:text-neutral-200 tabular-nums mt-0.5">
                    {selectedPkg.size}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-neutral-400 uppercase">License</div>
                  <div className="font-semibold text-xs text-neutral-800 dark:text-neutral-200 mt-0.5">
                    GPL v3 / FOSS
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
