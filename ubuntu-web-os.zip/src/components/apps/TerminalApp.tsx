/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { mockFS } from '../../services/mockFileSystem';

interface TerminalLine {
  id: string;
  type: 'input' | 'output' | 'error' | 'ascii';
  text: string;
  cwd?: string;
}

interface TerminalAppProps {
  onLaunchApp?: (appId: string, params?: any) => void;
}

export const TerminalApp: React.FC<TerminalAppProps> = ({ onLaunchApp }) => {
  const [cwd, setCwd] = useState('/home/ubuntu');
  const [inputVal, setInputVal] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [historyIdx, setHistoryIdx] = useState<number>(-1);
  const [lines, setLines] = useState<TerminalLine[]>([
    {
      id: 'welcome',
      type: 'output',
      text: 'Ubuntu 24.04 LTS (GNU/Linux 6.8.0-31-generic x86_64)\nType "help" to see available commands or "neofetch" for system specifications.',
    },
  ]);
  const [isMatrixMode, setIsMatrixMode] = useState(false);
  const [isHtopMode, setIsHtopMode] = useState(false);
  const [htopCpu, setHtopCpu] = useState<number[]>([14, 28, 9, 42]);
  const [htopMem, setHtopMem] = useState(24);

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [lines, isMatrixMode, isHtopMode]);

  // Focus input when clicking anywhere in terminal
  const handleContainerClick = () => {
    inputRef.current?.focus();
  };

  // Live htop simulation
  useEffect(() => {
    if (!isHtopMode) return;
    const interval = setInterval(() => {
      setHtopCpu([
        Math.floor(10 + Math.random() * 40),
        Math.floor(15 + Math.random() * 50),
        Math.floor(8 + Math.random() * 30),
        Math.floor(20 + Math.random() * 60),
      ]);
      setHtopMem((prev) => Math.min(65, Math.max(18, prev + (Math.random() * 4 - 2))));
    }, 1200);
    return () => clearInterval(interval);
  }, [isHtopMode]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (isMatrixMode || isHtopMode) {
      if (e.key === 'q' || (e.ctrlKey && e.key === 'c')) {
        setIsMatrixMode(false);
        setIsHtopMode(false);
      }
      return;
    }

    if (e.key === 'Enter') {
      executeCommand(inputVal);
      setInputVal('');
      setHistoryIdx(-1);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (history.length === 0) return;
      const nextIdx = historyIdx === -1 ? history.length - 1 : Math.max(0, historyIdx - 1);
      setHistoryIdx(nextIdx);
      setInputVal(history[nextIdx] || '');
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIdx === -1) return;
      const nextIdx = historyIdx + 1;
      if (nextIdx >= history.length) {
        setHistoryIdx(-1);
        setInputVal('');
      } else {
        setHistoryIdx(nextIdx);
        setInputVal(history[nextIdx] || '');
      }
    } else if (e.key === 'Tab') {
      e.preventDefault();
      // Auto complete
      const parts = inputVal.split(' ');
      const last = parts[parts.length - 1];
      if (last) {
        const items = mockFS.getDirectoryContents(cwd);
        const match = items.find((i) => i.name.toLowerCase().startsWith(last.toLowerCase()));
        if (match) {
          parts[parts.length - 1] = match.name;
          setInputVal(parts.join(' '));
        }
      }
    } else if (e.ctrlKey && e.key === 'l') {
      e.preventDefault();
      setLines([]);
    }
  };

  const executeCommand = (cmdStr: string) => {
    const trimmed = cmdStr.trim();
    if (!trimmed) {
      setLines((prev) => [
        ...prev,
        { id: Math.random().toString(), type: 'input', text: '', cwd },
      ]);
      return;
    }

    // Add to history
    setHistory((prev) => [...prev, trimmed]);

    const parts = trimmed.split(' ');
    const cmd = parts[0].toLowerCase();
    const args = parts.slice(1);

    const inputLine: TerminalLine = {
      id: Math.random().toString(),
      type: 'input',
      text: trimmed,
      cwd,
    };

    let resultLines: TerminalLine[] = [];

    switch (cmd) {
      case 'help':
        resultLines.push({
          id: Math.random().toString(),
          type: 'output',
          text: `Ubuntu 24.04 LTS Commands:
  neofetch / fastfetch  - Display system hardware & OS info
  ls [-la]              - List files and folders
  cd <dir>              - Change directory (supports .., ~, /)
  cat <file>            - View contents of a file
  pwd                   - Print current working directory
  mkdir <name>          - Create a new directory
  touch <name>          - Create a new empty file
  rm <name>             - Remove a file or directory
  echo <text>           - Print text to terminal
  htop / top            - Interactive live system monitor (press 'q' to exit)
  matrix                - Falling green matrix rain effect (press 'q' to exit)
  cowsay <text>         - Ask the talking cow
  uname -a              - Print kernel and architecture details
  whoami                - Current logged-in user
  date                  - Print current date and time
  calc <expr>           - Evaluate math expression
  open <app>            - Launch app (terminal, files, browser, editor, calc, settings)
  clear                 - Clear the terminal screen (or Ctrl+L)`,
        });
        break;

      case 'clear':
        setLines([]);
        return;

      case 'neofetch':
      case 'fastfetch':
        resultLines.push({
          id: Math.random().toString(),
          type: 'ascii',
          text: `         _nnnn_             ubuntu@noble-numbat
        dGGGGMMb            -------------------
       @p~qp~~qMb           OS: Ubuntu 24.04 LTS x86_64
       M|@||@) M|           Host: Web Browser Virtual Machine
       @,----.JM|           Kernel: 6.8.0-31-generic
      JS^\\__/  qKL          Uptime: 4 hours, 18 mins
     dZP        qKRb        Packages: 1842 (dpkg), 12 (snap)
    dZP          qKKb       Shell: bash 5.2.21
   fZP            SMMb      Resolution: 1920x1080
   HZM            MMMM      DE: GNOME 46 (Yaru-Dark)
   FqM            MMMM      WM: Mutter (HTML5 Compositor)
 __| ".        |\\dS"qML     Terminal: gnome-terminal
 |    \`-.__..--'  |  \`K.    CPU: Virtual Octa-Core (8) @ 3.400GHz
 |       -..      |    \`    GPU: WebGL 2.0 Hardware Accelerated
 |                |         Memory: 3.24GiB / 16.00GiB (20%)
 ------------------
 [●][●][●][●][●][●][●][●]`,
        });
        break;

      case 'pwd':
        resultLines.push({
          id: Math.random().toString(),
          type: 'output',
          text: cwd,
        });
        break;

      case 'whoami':
        resultLines.push({
          id: Math.random().toString(),
          type: 'output',
          text: 'ubuntu',
        });
        break;

      case 'date':
        resultLines.push({
          id: Math.random().toString(),
          type: 'output',
          text: new Date().toString(),
        });
        break;

      case 'uname':
        resultLines.push({
          id: Math.random().toString(),
          type: 'output',
          text: 'Linux noble-numbat 6.8.0-31-generic #31-Ubuntu SMP PREEMPT_DYNAMIC x86_64 GNU/Linux',
        });
        break;

      case 'ls': {
        const isAll = args.includes('-a') || args.includes('-la') || args.includes('-al');
        const items = mockFS.getDirectoryContents(cwd);
        if (items.length === 0) {
          resultLines.push({
            id: Math.random().toString(),
            type: 'output',
            text: isAll ? '.  ..' : '',
          });
        } else {
          const formatted = items
            .map((item) => (item.type === 'folder' ? `\x1b[34m${item.name}/\x1b[0m` : item.name))
            .join('  ');
          resultLines.push({
            id: Math.random().toString(),
            type: 'output',
            text: formatted,
          });
        }
        break;
      }

      case 'cd': {
        const target = args[0] || '~';
        let newPath = cwd;

        if (target === '~' || target === '') {
          newPath = '/home/ubuntu';
        } else if (target === '/') {
          newPath = '/';
        } else if (target === '..') {
          if (cwd !== '/') {
            const idx = cwd.lastIndexOf('/');
            newPath = idx === 0 ? '/' : cwd.substring(0, idx);
          }
        } else if (target.startsWith('/')) {
          newPath = target;
        } else {
          newPath = cwd === '/' ? `/${target}` : `${cwd}/${target}`;
        }

        // Verify folder exists or is known system root
        const exists =
          newPath === '/' ||
          newPath === '/home' ||
          newPath === '/home/ubuntu' ||
          mockFS.getFileByPath(newPath)?.type === 'folder';

        if (exists) {
          setCwd(newPath);
        } else {
          resultLines.push({
            id: Math.random().toString(),
            type: 'error',
            text: `bash: cd: ${target}: No such file or directory`,
          });
        }
        break;
      }

      case 'cat': {
        if (!args[0]) {
          resultLines.push({
            id: Math.random().toString(),
            type: 'error',
            text: 'cat: missing file operand',
          });
        } else {
          const filePath = args[0].startsWith('/') ? args[0] : `${cwd}/${args[0]}`;
          const file = mockFS.getFileByPath(filePath);
          if (!file) {
            resultLines.push({
              id: Math.random().toString(),
              type: 'error',
              text: `cat: ${args[0]}: No such file or directory`,
            });
          } else if (file.type === 'folder') {
            resultLines.push({
              id: Math.random().toString(),
              type: 'error',
              text: `cat: ${args[0]}: Is a directory`,
            });
          } else {
            resultLines.push({
              id: Math.random().toString(),
              type: 'output',
              text: file.content || '(empty)',
            });
          }
        }
        break;
      }

      case 'echo': {
        const fullArg = args.join(' ');
        // Check redirection
        if (fullArg.includes('>')) {
          const [textPart, filePart] = fullArg.split('>');
          const fileName = filePart.trim();
          const content = textPart.trim().replace(/^["']|["']$/g, '');
          mockFS.createFile(cwd, fileName, content);
          resultLines.push({
            id: Math.random().toString(),
            type: 'output',
            text: `[Created ${fileName}]`,
          });
        } else {
          resultLines.push({
            id: Math.random().toString(),
            type: 'output',
            text: fullArg.replace(/^["']|["']$/g, ''),
          });
        }
        break;
      }

      case 'mkdir': {
        if (!args[0]) {
          resultLines.push({
            id: Math.random().toString(),
            type: 'error',
            text: 'mkdir: missing operand',
          });
        } else {
          mockFS.createFolder(cwd, args[0]);
          resultLines.push({
            id: Math.random().toString(),
            type: 'output',
            text: `Created directory: ${args[0]}`,
          });
        }
        break;
      }

      case 'touch': {
        if (!args[0]) {
          resultLines.push({
            id: Math.random().toString(),
            type: 'error',
            text: 'touch: missing file operand',
          });
        } else {
          mockFS.createFile(cwd, args[0], '');
        }
        break;
      }

      case 'rm': {
        if (!args[0]) {
          resultLines.push({
            id: Math.random().toString(),
            type: 'error',
            text: 'rm: missing operand',
          });
        } else {
          const path = args[0].startsWith('/') ? args[0] : `${cwd}/${args[0]}`;
          const ok = mockFS.deleteItem(path);
          if (!ok) {
            resultLines.push({
              id: Math.random().toString(),
              type: 'error',
              text: `rm: cannot remove '${args[0]}': No such file or directory`,
            });
          }
        }
        break;
      }

      case 'cowsay': {
        const msg = args.join(' ') || 'Ubuntu is awesome!';
        const borderLen = msg.length + 2;
        const line = '-'.repeat(borderLen);
        const cow = `
 ${line}
< ${msg} >
 ${line}
        \\   ^__^
         \\  (oo)\\_______
            (__)\\       )\\/\\
                ||----w |
                ||     ||`;
        resultLines.push({
          id: Math.random().toString(),
          type: 'ascii',
          text: cow,
        });
        break;
      }

      case 'calc': {
        try {
          const expr = args.join(' ');
          // Safe simple evaluator for math only
          const sanitized = expr.replace(/[^0-9+\-*/().]/g, '');
          const val = Function(`'use strict'; return (${sanitized})`)();
          resultLines.push({
            id: Math.random().toString(),
            type: 'output',
            text: `= ${val}`,
          });
        } catch {
          resultLines.push({
            id: Math.random().toString(),
            type: 'error',
            text: 'calc: invalid math expression',
          });
        }
        break;
      }

      case 'matrix':
        setIsMatrixMode(true);
        return;

      case 'htop':
      case 'top':
        setIsHtopMode(true);
        return;

      case 'open': {
        const appName = args[0]?.toLowerCase();
        if (appName && onLaunchApp) {
          onLaunchApp(appName);
          resultLines.push({
            id: Math.random().toString(),
            type: 'output',
            text: `Launching ${appName}...`,
          });
        } else {
          resultLines.push({
            id: Math.random().toString(),
            type: 'output',
            text: 'Usage: open <terminal|files|browser|editor|calc|calendar|settings|music|software>',
          });
        }
        break;
      }

      default:
        resultLines.push({
          id: Math.random().toString(),
          type: 'error',
          text: `Command '${cmd}' not found. Type 'help' for available commands.`,
        });
        break;
    }

    setLines((prev) => [...prev, inputLine, ...resultLines]);
  };

  const formatCwd = (path: string) => {
    return path.replace('/home/ubuntu', '~');
  };

  return (
    <div
      onClick={handleContainerClick}
      className="w-full h-full bg-[#300A24] text-white font-mono text-sm p-3.5 overflow-y-auto selection:bg-[#E95420] selection:text-white flex flex-col cursor-text select-text"
      style={{ fontFamily: "'Ubuntu Mono', monospace" }}
    >
      {/* Matrix Mode */}
      {isMatrixMode && (
        <div className="absolute inset-0 bg-black/95 z-20 p-4 font-mono text-emerald-400 overflow-hidden flex flex-col justify-between">
          <div className="flex justify-between items-center text-xs text-emerald-600 border-b border-emerald-900 pb-2 mb-2">
            <span>MATRIX PROTOCOL TERMINAL [SIMULATION ACTIVE]</span>
            <button
              onClick={() => setIsMatrixMode(false)}
              className="px-2 py-0.5 bg-emerald-950 border border-emerald-800 rounded text-emerald-300 hover:bg-emerald-900"
            >
              Exit (q)
            </button>
          </div>
          <div className="flex-1 overflow-hidden grid grid-cols-12 gap-1 text-[11px] leading-tight select-none opacity-90 animate-pulse">
            {Array.from({ length: 48 }).map((_, i) => (
              <div key={i} className="flex flex-col">
                {Array.from({ length: 22 }).map((_, j) => (
                  <span
                    key={j}
                    style={{
                      opacity: ((i + j * 7) % 10) / 10 + 0.1,
                      color: (i + j) % 5 === 0 ? '#ffffff' : '#10b981',
                    }}
                  >
                    {String.fromCharCode(33 + ((i * 17 + j * 31) % 90))}
                  </span>
                ))}
              </div>
            ))}
          </div>
          <div className="text-xs text-center text-emerald-500 pt-2 border-t border-emerald-900">
            Press 'q' or click Exit to return to bash shell
          </div>
        </div>
      )}

      {/* HTOP Mode */}
      {isHtopMode && (
        <div className="absolute inset-0 bg-[#1e1e1e] z-20 p-3 font-mono text-xs text-neutral-200 overflow-y-auto flex flex-col">
          <div className="flex justify-between items-center border-b border-neutral-700 pb-2 mb-3">
            <span className="font-bold text-white">htop - 24.04 LTS Process Monitor</span>
            <button
              onClick={() => setIsHtopMode(false)}
              className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 border border-neutral-600 rounded text-xs text-white"
            >
              Quit (q)
            </button>
          </div>

          {/* CPU meters */}
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 mb-3 bg-neutral-900/60 p-2.5 rounded border border-neutral-800">
            {htopCpu.map((usage, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <span className="text-cyan-400 font-semibold w-6">CPU{idx}:</span>
                <div className="flex-1 bg-neutral-800 h-2 rounded overflow-hidden">
                  <div
                    className={`h-full ${
                      usage > 70 ? 'bg-red-500' : usage > 40 ? 'bg-amber-500' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${usage}%` }}
                  />
                </div>
                <span className="w-10 text-right tabular-nums text-neutral-400">{usage}%</span>
              </div>
            ))}
            <div className="flex items-center gap-2 col-span-2 pt-1 border-t border-neutral-800 mt-1">
              <span className="text-purple-400 font-semibold w-12">Mem:</span>
              <div className="flex-1 bg-neutral-800 h-2 rounded overflow-hidden">
                <div className="h-full bg-purple-500" style={{ width: `${htopMem}%` }} />
              </div>
              <span className="text-right tabular-nums text-neutral-400">
                {(htopMem * 0.16).toFixed(1)}G / 16.0G
              </span>
            </div>
          </div>

          {/* Process list table */}
          <div className="flex-1 overflow-x-auto">
            <table className="w-full text-left text-[11px]">
              <thead>
                <tr className="bg-neutral-800 text-neutral-400 font-semibold">
                  <th className="p-1">PID</th>
                  <th className="p-1">USER</th>
                  <th className="p-1">PRI</th>
                  <th className="p-1">NI</th>
                  <th className="p-1">VIRT</th>
                  <th className="p-1">RES</th>
                  <th className="p-1">CPU%</th>
                  <th className="p-1">MEM%</th>
                  <th className="p-1">Command</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800 text-neutral-300">
                <tr>
                  <td className="p-1 text-cyan-400">1204</td>
                  <td className="p-1 text-emerald-400">ubuntu</td>
                  <td className="p-1">20</td>
                  <td className="p-1">0</td>
                  <td className="p-1">2.4G</td>
                  <td className="p-1">420M</td>
                  <td className="p-1 text-amber-400">{htopCpu[0]}%</td>
                  <td className="p-1">3.1%</td>
                  <td className="p-1 font-semibold text-white">/usr/bin/gnome-shell</td>
                </tr>
                <tr>
                  <td className="p-1 text-cyan-400">1452</td>
                  <td className="p-1 text-emerald-400">ubuntu</td>
                  <td className="p-1">20</td>
                  <td className="p-1">0</td>
                  <td className="p-1">890M</td>
                  <td className="p-1">140M</td>
                  <td className="p-1 text-amber-400">{(htopCpu[1] * 0.4).toFixed(0)}%</td>
                  <td className="p-1">1.2%</td>
                  <td className="p-1">/usr/bin/mutter-x11-frames</td>
                </tr>
                <tr>
                  <td className="p-1 text-cyan-400">2109</td>
                  <td className="p-1 text-emerald-400">ubuntu</td>
                  <td className="p-1">20</td>
                  <td className="p-1">0</td>
                  <td className="p-1">412M</td>
                  <td className="p-1">64M</td>
                  <td className="p-1 text-amber-400">{(htopCpu[2] * 0.3).toFixed(0)}%</td>
                  <td className="p-1">0.8%</td>
                  <td className="p-1">gnome-terminal-server</td>
                </tr>
                <tr>
                  <td className="p-1 text-cyan-400">1</td>
                  <td className="p-1 text-blue-400">root</td>
                  <td className="p-1">20</td>
                  <td className="p-1">0</td>
                  <td className="p-1">168M</td>
                  <td className="p-1">12M</td>
                  <td className="p-1">0.0%</td>
                  <td className="p-1">0.1%</td>
                  <td className="p-1">/sbin/init</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className="text-[10px] text-neutral-500 pt-2 border-t border-neutral-800">
            F1 Help  |  F9 Kill  |  q Quit
          </div>
        </div>
      )}

      {/* Terminal History Lines */}
      {lines.map((line) => (
        <div key={line.id} className="mb-1 leading-relaxed">
          {line.type === 'input' && (
            <div className="flex flex-wrap items-baseline gap-x-1.5">
              <span className="text-[#4E9A06] font-bold">ubuntu@noble-numbat</span>
              <span className="text-neutral-400">:</span>
              <span className="text-[#3465A4] font-bold">{formatCwd(line.cwd || cwd)}</span>
              <span className="text-white font-bold">$</span>
              <span className="text-white font-normal">{line.text}</span>
            </div>
          )}
          {line.type === 'output' && (
            <pre className="whitespace-pre-wrap text-neutral-200">{line.text}</pre>
          )}
          {line.type === 'error' && (
            <pre className="whitespace-pre-wrap text-[#EF2929]">{line.text}</pre>
          )}
          {line.type === 'ascii' && (
            <pre className="whitespace-pre text-[#E95420] font-bold text-xs leading-none py-1">
              {line.text}
            </pre>
          )}
        </div>
      ))}

      {/* Active Input Line */}
      <div className="flex items-center gap-x-1.5 mt-0.5">
        <span className="text-[#4E9A06] font-bold shrink-0">ubuntu@noble-numbat</span>
        <span className="text-neutral-400 shrink-0">:</span>
        <span className="text-[#3465A4] font-bold shrink-0">{formatCwd(cwd)}</span>
        <span className="text-white font-bold shrink-0">$</span>
        <input
          ref={inputRef}
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          onKeyDown={handleKeyDown}
          autoFocus
          spellCheck={false}
          autoComplete="off"
          className="flex-1 bg-transparent border-none outline-none text-white font-mono p-0 m-0 caret-[#E95420]"
        />
      </div>

      <div ref={bottomRef} />
    </div>
  );
};
