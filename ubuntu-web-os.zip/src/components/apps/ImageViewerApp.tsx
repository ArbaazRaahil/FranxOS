/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  ZoomIn,
  ZoomOut,
  RotateCw,
  Maximize2,
  Image as ImageIcon,
  Check,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { mockFS } from '../../services/mockFileSystem';
import { FileItem } from '../../types/os';

interface ImageViewerAppProps {
  initialFile?: FileItem | null;
  onSetWallpaper?: (css: string, name: string) => void;
}

export const ImageViewerApp: React.FC<ImageViewerAppProps> = ({ initialFile, onSetWallpaper }) => {
  const [images, setImages] = useState<FileItem[]>([]);
  const [selectedIdx, setSelectedIdx] = useState(0);
  const [zoom, setZoom] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [wallpaperSetSuccess, setWallpaperSetSuccess] = useState(false);

  useEffect(() => {
    const pictures = mockFS.getDirectoryContents('/home/ubuntu/Pictures');
    const imageFiles = pictures.filter((f) => f.type === 'file');
    setImages(imageFiles);

    if (initialFile) {
      const idx = imageFiles.findIndex((f) => f.path === initialFile.path);
      if (idx !== -1) setSelectedIdx(idx);
    }
  }, [initialFile]);

  const activeImage = images[selectedIdx];

  const handleZoomIn = () => setZoom((prev) => Math.min(250, prev + 25));
  const handleZoomOut = () => setZoom((prev) => Math.max(50, prev - 25));
  const handleRotate = () => setRotation((prev) => (prev + 90) % 360);
  const handleReset = () => {
    setZoom(100);
    setRotation(0);
  };

  const handleApplyWallpaper = () => {
    if (!activeImage || !onSetWallpaper) return;
    // We can generate wallpaper background
    const bgStyle = activeImage.name.includes('Aubergine')
      ? 'linear-gradient(135deg, #300A24 0%, #5E2750 40%, #E95420 80%, #FFA447 100%)'
      : 'radial-gradient(ellipse at 70% 30%, #772953 0%, #300A24 60%, #150210 100%)';
    onSetWallpaper(bgStyle, activeImage.name);
    setWallpaperSetSuccess(true);
    setTimeout(() => setWallpaperSetSuccess(false), 2500);
  };

  return (
    <div className="w-full h-full flex flex-col bg-neutral-900 text-neutral-100 select-none text-sm overflow-hidden">
      {/* Top Controls Bar */}
      <div className="h-11 bg-neutral-950 border-b border-neutral-800 px-4 flex items-center justify-between">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setSelectedIdx((prev) => (prev - 1 + images.length) % images.length)}
            disabled={images.length <= 1}
            className="p-1.5 rounded hover:bg-neutral-800 disabled:opacity-30"
            title="Previous Image"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-xs text-neutral-400 px-2 font-mono">
            {images.length > 0 ? `${selectedIdx + 1} / ${images.length}` : '0 / 0'}
          </span>
          <button
            onClick={() => setSelectedIdx((prev) => (prev + 1) % images.length)}
            disabled={images.length <= 1}
            className="p-1.5 rounded hover:bg-neutral-800 disabled:opacity-30"
            title="Next Image"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button onClick={handleZoomOut} className="p-1.5 rounded hover:bg-neutral-800" title="Zoom Out">
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono text-neutral-400 w-12 text-center">{zoom}%</span>
          <button onClick={handleZoomIn} className="p-1.5 rounded hover:bg-neutral-800" title="Zoom In">
            <ZoomIn className="w-4 h-4" />
          </button>
          <button onClick={handleRotate} className="p-1.5 rounded hover:bg-neutral-800" title="Rotate 90°">
            <RotateCw className="w-4 h-4" />
          </button>
          <button onClick={handleReset} className="p-1.5 rounded hover:bg-neutral-800" title="Fit to Window">
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>

        <div>
          <button
            onClick={handleApplyWallpaper}
            className="px-3 py-1 bg-[#E95420] hover:bg-[#d84a1b] text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            {wallpaperSetSuccess ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Applied as Wallpaper</span>
              </>
            ) : (
              <>
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Set as Wallpaper</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Image Canvas Viewport */}
      <div className="flex-1 flex items-center justify-center p-6 overflow-hidden bg-neutral-900 relative">
        {activeImage && activeImage.content ? (
          <div
            className="transition-transform duration-200 shadow-2xl rounded-lg overflow-hidden max-w-full max-h-full flex items-center justify-center"
            style={{
              transform: `scale(${zoom / 100}) rotate(${rotation}deg)`,
              maxWidth: '85%',
              maxHeight: '85%',
            }}
            dangerouslySetInnerHTML={{ __html: activeImage.content }}
          />
        ) : (
          <div className="text-neutral-500 text-xs">No image selected</div>
        )}
      </div>

      {/* Image Info & Thumbnail strip */}
      <div className="h-16 bg-neutral-950 border-t border-neutral-800 px-4 flex items-center justify-between">
        <div className="text-xs">
          <span className="font-semibold text-white">{activeImage?.name || 'Image'}</span>
          <span className="text-neutral-500 ml-2">SVG Vector graphic</span>
        </div>

        {/* Carousel thumbnails */}
        <div className="flex items-center gap-2 overflow-x-auto">
          {images.map((img, idx) => (
            <div
              key={img.id}
              onClick={() => {
                setSelectedIdx(idx);
                handleReset();
              }}
              className={`w-12 h-10 rounded border-2 cursor-pointer overflow-hidden p-0.5 ${
                idx === selectedIdx ? 'border-[#E95420]' : 'border-neutral-800 hover:border-neutral-600'
              }`}
              dangerouslySetInnerHTML={{ __html: img.content || '' }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
