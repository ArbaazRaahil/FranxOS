/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Shuffle,
  Repeat,
  Music,
  Disc,
} from 'lucide-react';
import { soundService } from '../../services/soundEffects';

interface Track {
  id: number;
  title: string;
  artist: string;
  album: string;
  duration: string;
  synthScale: number;
}

const TRACKS: Track[] = [
  {
    id: 1,
    title: 'Noble Numbat Dawn',
    artist: 'Canonical Synthesizer Lab',
    album: 'Ubuntu 24.04 Soundscapes',
    duration: '3:45',
    synthScale: 0,
  },
  {
    id: 2,
    title: 'Aubergine Groove',
    artist: 'Yaru Sound Engine',
    album: 'Ubuntu 24.04 Soundscapes',
    duration: '4:12',
    synthScale: 1,
  },
  {
    id: 3,
    title: 'Terminal Rain & Monospace',
    artist: 'GNU Audio Collective',
    album: 'Kernel 6.8 Frequencies',
    duration: '3:18',
    synthScale: 2,
  },
];

export const MusicApp: React.FC = () => {
  const [currentTrackIdx, setCurrentTrackIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(70);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(25);
  const [visualizerBars, setVisualizerBars] = useState<number[]>(
    Array.from({ length: 18 }, () => Math.floor(Math.random() * 60 + 20))
  );

  const currentTrack = TRACKS[currentTrackIdx];

  // Equalizer visualizer effect
  useEffect(() => {
    let animId: any;
    if (isPlaying) {
      animId = setInterval(() => {
        setVisualizerBars(
          Array.from({ length: 18 }, () => Math.floor(Math.random() * 80 + 15))
        );
        setProgress((prev) => (prev >= 100 ? 0 : prev + 0.3));
      }, 180);
    } else {
      setVisualizerBars(Array.from({ length: 18 }, () => 8));
    }
    return () => clearInterval(animId);
  }, [isPlaying]);

  const togglePlay = () => {
    if (isPlaying) {
      soundService.stopAmbientTrack();
      setIsPlaying(false);
    } else {
      soundService.startAmbientTrack(currentTrack.synthScale);
      setIsPlaying(true);
    }
  };

  const handleNext = () => {
    const nextIdx = (currentTrackIdx + 1) % TRACKS.length;
    setCurrentTrackIdx(nextIdx);
    if (isPlaying) {
      soundService.startAmbientTrack(TRACKS[nextIdx].synthScale);
    }
  };

  const handlePrev = () => {
    const prevIdx = (currentTrackIdx - 1 + TRACKS.length) % TRACKS.length;
    setCurrentTrackIdx(prevIdx);
    if (isPlaying) {
      soundService.startAmbientTrack(TRACKS[prevIdx].synthScale);
    }
  };

  useEffect(() => {
    return () => {
      soundService.stopAmbientTrack();
    };
  }, []);

  return (
    <div className="w-full h-full flex flex-col bg-neutral-900 text-white select-none text-sm overflow-hidden">
      {/* Top Main Player Display */}
      <div className="flex-1 p-6 flex flex-col md:flex-row items-center gap-6 bg-gradient-to-b from-[#300A24] via-[#220719] to-neutral-900">
        {/* Album Art with spinning disc */}
        <div className="relative w-44 h-44 rounded-2xl bg-gradient-to-tr from-[#E95420] to-[#772953] flex items-center justify-center shadow-2xl shrink-0 border border-white/10 group">
          <div
            className={`w-32 h-32 rounded-full border-4 border-black/40 flex items-center justify-center bg-black/60 shadow-inner ${
              isPlaying ? 'animate-spin' : ''
            }`}
            style={{ animationDuration: '6s' }}
          >
            <div className="w-12 h-12 rounded-full bg-[#E95420] flex items-center justify-center text-white font-bold text-xs">
              YARU
            </div>
          </div>
          <Disc className="w-6 h-6 text-white/50 absolute top-3 right-3" />
        </div>

        {/* Track Details & Visualizer */}
        <div className="flex-1 flex flex-col justify-between w-full">
          <div>
            <span className="text-[11px] font-bold text-[#E95420] uppercase tracking-wider">
              Now Playing
            </span>
            <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
              {currentTrack.title}
            </h1>
            <p className="text-xs text-neutral-400 mt-0.5">
              {currentTrack.artist} · {currentTrack.album}
            </p>
          </div>

          {/* Audio Visualizer Spectrum Bars */}
          <div className="h-16 flex items-end gap-1.5 my-4 bg-black/30 p-2 rounded-xl border border-white/5">
            {visualizerBars.map((height, i) => (
              <div
                key={i}
                className="flex-1 bg-gradient-to-t from-[#E95420] to-[#FFA447] rounded-t-sm transition-all duration-150"
                style={{ height: `${height}%` }}
              />
            ))}
          </div>

          {/* Scrubber Progress Bar */}
          <div className="space-y-1">
            <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden cursor-pointer">
              <div
                className="bg-[#E95420] h-full transition-all duration-150"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="flex justify-between text-[10px] text-neutral-500 font-mono">
              <span>0:{Math.floor(progress * 1.5).toString().padStart(2, '0')}</span>
              <span>{currentTrack.duration}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Track List */}
      <div className="h-36 bg-neutral-950 border-t border-neutral-800 p-2 overflow-y-auto">
        <div className="text-[10px] font-bold text-neutral-500 uppercase px-3 py-1">Playlist</div>
        {TRACKS.map((t, idx) => {
          const isSelected = idx === currentTrackIdx;
          return (
            <div
              key={t.id}
              onClick={() => {
                setCurrentTrackIdx(idx);
                if (isPlaying) {
                  soundService.startAmbientTrack(t.synthScale);
                }
              }}
              className={`flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer transition-colors text-xs ${
                isSelected
                  ? 'bg-[#E95420]/20 text-[#FFA447] font-semibold'
                  : 'hover:bg-neutral-800/60 text-neutral-400'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="font-mono text-neutral-600 w-4">{idx + 1}</span>
                <span className="text-white">{t.title}</span>
              </div>
              <div className="flex items-center gap-4 text-[11px] text-neutral-500">
                <span>{t.artist}</span>
                <span className="font-mono">{t.duration}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Controls Bar */}
      <div className="h-16 bg-neutral-900 border-t border-neutral-800 px-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button className="text-neutral-500 hover:text-white" title="Shuffle">
            <Shuffle className="w-4 h-4" />
          </button>
          <button onClick={handlePrev} className="text-neutral-300 hover:text-white" title="Previous">
            <SkipBack className="w-5 h-5" />
          </button>
          <button
            onClick={togglePlay}
            className="w-10 h-10 rounded-full bg-[#E95420] hover:bg-[#d84a1b] text-white flex items-center justify-center shadow-md transition-transform active:scale-95"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 ml-0.5 fill-current" />}
          </button>
          <button onClick={handleNext} className="text-neutral-300 hover:text-white" title="Next">
            <SkipForward className="w-5 h-5" />
          </button>
          <button className="text-neutral-500 hover:text-white" title="Repeat">
            <Repeat className="w-4 h-4" />
          </button>
        </div>

        {/* Volume controls */}
        <div className="flex items-center gap-2">
          <button onClick={() => setIsMuted(!isMuted)} className="text-neutral-400 hover:text-white">
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <input
            type="range"
            min="0"
            max="100"
            value={isMuted ? 0 : volume}
            onChange={(e) => {
              setVolume(Number(e.target.value));
              setIsMuted(false);
            }}
            className="w-24 accent-[#E95420] h-1.5 bg-neutral-700 rounded-lg appearance-none cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
};
