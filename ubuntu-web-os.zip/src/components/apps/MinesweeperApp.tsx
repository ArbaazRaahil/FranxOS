/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Bomb, Flag, RotateCcw, Trophy, Smile, Frown, Meh } from 'lucide-react';

type CellState = {
  isMine: boolean;
  isRevealed: boolean;
  isFlagged: boolean;
  neighborCount: number;
};

export const MinesweeperApp: React.FC = () => {
  const ROWS = 9;
  const COLS = 9;
  const MINES = 10;

  const [grid, setGrid] = useState<CellState[][]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [gameWon, setGameWon] = useState(false);
  const [mineCount, setMineCount] = useState(MINES);
  const [timer, setTimer] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [flagMode, setFlagMode] = useState(false);

  // Initialize board
  const initGame = () => {
    const newGrid: CellState[][] = [];
    for (let r = 0; r < ROWS; r++) {
      const row: CellState[] = [];
      for (let c = 0; c < COLS; c++) {
        row.push({
          isMine: false,
          isRevealed: false,
          isFlagged: false,
          neighborCount: 0,
        });
      }
      newGrid.push(row);
    }

    // Place mines randomly
    let placed = 0;
    while (placed < MINES) {
      const r = Math.floor(Math.random() * ROWS);
      const c = Math.floor(Math.random() * COLS);
      if (!newGrid[r][c].isMine) {
        newGrid[r][c].isMine = true;
        placed++;
      }
    }

    // Calculate neighbor counts
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        if (!newGrid[r][c].isMine) {
          let count = 0;
          for (let dr = -1; dr <= 1; dr++) {
            for (let dc = -1; dc <= 1; dc++) {
              const nr = r + dr;
              const nc = c + dc;
              if (nr >= 0 && nr < ROWS && nc >= 0 && nc < COLS && newGrid[nr][nc].isMine) {
                count++;
              }
            }
          }
          newGrid[r][c].neighborCount = count;
        }
      }
    }

    setGrid(newGrid);
    setGameOver(false);
    setGameWon(false);
    setMineCount(MINES);
    setTimer(0);
    setIsTimerRunning(false);
  };

  useEffect(() => {
    initGame();
  }, []);

  // Timer
  useEffect(() => {
    let interval: any;
    if (isTimerRunning && !gameOver && !gameWon) {
      interval = setInterval(() => setTimer((t) => t + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, gameOver, gameWon]);

  // Reveal cell recursively
  const revealCell = (r: number, c: number) => {
    if (gameOver || gameWon || grid[r][c].isRevealed || grid[r][c].isFlagged) return;

    if (!isTimerRunning) setIsTimerRunning(true);

    const next = grid.map((row) => row.map((cell) => ({ ...cell })));

    if (next[r][c].isMine) {
      // Reveal all mines
      for (let row = 0; row < ROWS; row++) {
        for (let col = 0; col < COLS; col++) {
          if (next[row][col].isMine) next[row][col].isRevealed = true;
        }
      }
      setGrid(next);
      setGameOver(true);
      setIsTimerRunning(false);
      return;
    }

    // Flood fill zero neighbor cells
    const flood = (cr: number, cc: number) => {
      if (cr < 0 || cr >= ROWS || cc < 0 || cc >= COLS || next[cr][cc].isRevealed || next[cr][cc].isFlagged) {
        return;
      }
      next[cr][cc].isRevealed = true;
      if (next[cr][cc].neighborCount === 0 && !next[cr][cc].isMine) {
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            flood(cr + dr, cc + dc);
          }
        }
      }
    };

    flood(r, c);
    setGrid(next);

    // Check win condition
    let unrevealedNonMines = 0;
    for (let row = 0; row < ROWS; row++) {
      for (let col = 0; col < COLS; col++) {
        if (!next[row][col].isMine && !next[row][col].isRevealed) {
          unrevealedNonMines++;
        }
      }
    }

    if (unrevealedNonMines === 0) {
      setGameWon(true);
      setIsTimerRunning(false);
    }
  };

  const toggleFlag = (r: number, c: number, e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    if (gameOver || gameWon || grid[r][c].isRevealed) return;

    const next = grid.map((row) => row.map((cell) => ({ ...cell })));
    const curr = next[r][c].isFlagged;
    next[r][c].isFlagged = !curr;
    setGrid(next);
    setMineCount((prev) => (curr ? prev + 1 : prev - 1));
  };

  const getNumberColor = (count: number) => {
    const colors = [
      '',
      'text-blue-500 font-bold',
      'text-emerald-500 font-bold',
      'text-red-500 font-bold',
      'text-purple-600 font-bold',
      'text-amber-600 font-bold',
      'text-teal-600 font-bold',
      'text-neutral-900 dark:text-neutral-100 font-bold',
      'text-neutral-500 font-bold',
    ];
    return colors[count] || '';
  };

  return (
    <div className="w-full h-full flex flex-col items-center justify-between bg-neutral-200 dark:bg-[#1E1E1E] text-neutral-800 dark:text-neutral-200 p-4 select-none">
      {/* Top Scoreboard Bar */}
      <div className="w-full max-w-xs bg-neutral-100 dark:bg-[#252526] border border-neutral-300 dark:border-neutral-700 rounded-xl p-3 flex items-center justify-between mb-4 shadow-sm">
        {/* Mine counter */}
        <div className="bg-neutral-900 text-red-500 font-mono text-xl px-2.5 py-1 rounded border border-neutral-800 tabular-nums">
          {String(mineCount).padStart(3, '0')}
        </div>

        {/* Reset button */}
        <button
          onClick={initGame}
          className="w-10 h-10 rounded-full bg-neutral-200 dark:bg-neutral-700 hover:bg-neutral-300 dark:hover:bg-neutral-600 flex items-center justify-center transition-transform active:scale-95 shadow-xs"
        >
          {gameOver ? (
            <Frown className="w-6 h-6 text-red-500" />
          ) : gameWon ? (
            <Smile className="w-6 h-6 text-emerald-500" />
          ) : (
            <Meh className="w-6 h-6 text-amber-500" />
          )}
        </button>

        {/* Timer */}
        <div className="bg-neutral-900 text-red-500 font-mono text-xl px-2.5 py-1 rounded border border-neutral-800 tabular-nums">
          {String(Math.min(999, timer)).padStart(3, '0')}
        </div>
      </div>

      {/* Flag Mode toggle for mobile/touch or easy clicking */}
      <div className="mb-2">
        <button
          onClick={() => setFlagMode(!flagMode)}
          className={`px-3 py-1 text-xs rounded-lg flex items-center gap-1.5 font-medium border transition-colors ${
            flagMode
              ? 'bg-red-500 text-white border-red-600'
              : 'bg-white dark:bg-neutral-800 border-neutral-300 dark:border-neutral-700'
          }`}
        >
          <Flag className="w-3.5 h-3.5" />
          <span>{flagMode ? 'Flag Placement Active' : 'Normal Dig Mode (Right-click to flag)'}</span>
        </button>
      </div>

      {/* Minesweeper Grid */}
      <div className="p-2 bg-neutral-300 dark:bg-neutral-800 rounded-xl border border-neutral-400 dark:border-neutral-700 shadow-inner">
        <div
          className="grid gap-1"
          style={{ gridTemplateColumns: `repeat(${COLS}, minmax(0, 1fr))` }}
        >
          {grid.map((row, r) =>
            row.map((cell, c) => (
              <button
                key={`${r}-${c}`}
                onClick={() => (flagMode ? toggleFlag(r, c) : revealCell(r, c))}
                onContextMenu={(e) => toggleFlag(r, c, e)}
                className={`w-8 h-8 rounded flex items-center justify-center font-bold text-sm transition-all ${
                  cell.isRevealed
                    ? cell.isMine
                      ? 'bg-red-500 text-white shadow-inner'
                      : 'bg-neutral-100 dark:bg-[#2A2A2A] shadow-inner'
                    : 'bg-neutral-200 dark:bg-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-600 shadow-xs border-t border-l border-white/50 border-b border-r border-black/20'
                }`}
              >
                {cell.isRevealed ? (
                  cell.isMine ? (
                    <Bomb className="w-4 h-4 fill-current animate-bounce" />
                  ) : cell.neighborCount > 0 ? (
                    <span className={getNumberColor(cell.neighborCount)}>
                      {cell.neighborCount}
                    </span>
                  ) : null
                ) : cell.isFlagged ? (
                  <Flag className="w-4 h-4 text-red-500 fill-red-500" />
                ) : null}
              </button>
            ))
          )}
        </div>
      </div>

      {/* Bottom info */}
      <div className="text-[11px] text-neutral-500 mt-4 text-center">
        {gameWon && <div className="text-emerald-500 font-bold mb-1">Victory! You cleared all mines!</div>}
        {gameOver && <div className="text-red-500 font-bold mb-1">Game Over! Detonated a mine!</div>}
        GNOME Mines · Ubuntu 24.04 LTS
      </div>
    </div>
  );
};
