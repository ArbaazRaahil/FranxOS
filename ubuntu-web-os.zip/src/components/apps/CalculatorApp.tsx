/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { History, Delete, CornerDownLeft } from 'lucide-react';

export const CalculatorApp: React.FC = () => {
  const [display, setDisplay] = useState('0');
  const [expression, setExpression] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [isScientific, setIsScientific] = useState(false);
  const [memory, setMemory] = useState<number | null>(null);

  const handleDigit = (digit: string) => {
    if (display === '0' || display === 'Error') {
      setDisplay(digit);
    } else {
      setDisplay(display + digit);
    }
  };

  const handleOperator = (op: string) => {
    setExpression(expression + display + ' ' + op + ' ');
    setDisplay('0');
  };

  const handleClear = () => {
    setDisplay('0');
    setExpression('');
  };

  const handleBackspace = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay('0');
    }
  };

  const handleCalculate = () => {
    try {
      const fullExpr = expression + display;
      // Sanitize safe math
      const sanitized = fullExpr
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/π/g, Math.PI.toString())
        .replace(/e/g, Math.E.toString());

      // Safe calculation without dangerous eval
      const result = Function(`'use strict'; return (${sanitized})`)();
      const formatted = Number.isInteger(result) ? result.toString() : Number(result.toFixed(8)).toString();

      setHistory((prev) => [`${fullExpr} = ${formatted}`, ...prev.slice(0, 15)]);
      setDisplay(formatted);
      setExpression('');
    } catch {
      setDisplay('Error');
    }
  };

  const handleSciOp = (op: string) => {
    const val = parseFloat(display);
    if (isNaN(val)) return;

    let res = 0;
    switch (op) {
      case 'sin':
        res = Math.sin((val * Math.PI) / 180);
        break;
      case 'cos':
        res = Math.cos((val * Math.PI) / 180);
        break;
      case 'tan':
        res = Math.tan((val * Math.PI) / 180);
        break;
      case 'sqrt':
        res = Math.sqrt(val);
        break;
      case 'sqr':
        res = Math.pow(val, 2);
        break;
      case 'ln':
        res = Math.log(val);
        break;
      case '1/x':
        res = 1 / val;
        break;
      default:
        break;
    }
    const formatted = Number(res.toFixed(8)).toString();
    setHistory((prev) => [`${op}(${val}) = ${formatted}`, ...prev.slice(0, 15)]);
    setDisplay(formatted);
  };

  return (
    <div className="w-full h-full flex flex-col bg-neutral-100 dark:bg-[#202020] text-neutral-800 dark:text-neutral-100 select-none text-sm p-4 overflow-hidden">
      {/* Mode toggle */}
      <div className="flex items-center justify-between pb-2 mb-2 border-b border-neutral-300 dark:border-neutral-700">
        <div className="flex bg-neutral-200 dark:bg-neutral-800 p-0.5 rounded-lg text-xs font-medium">
          <button
            onClick={() => setIsScientific(false)}
            className={`px-3 py-1 rounded-md transition-colors ${
              !isScientific ? 'bg-white dark:bg-neutral-700 shadow-xs text-[#E95420]' : 'text-neutral-500'
            }`}
          >
            Basic
          </button>
          <button
            onClick={() => setIsScientific(true)}
            className={`px-3 py-1 rounded-md transition-colors ${
              isScientific ? 'bg-white dark:bg-neutral-700 shadow-xs text-[#E95420]' : 'text-neutral-500'
            }`}
          >
            Scientific
          </button>
        </div>

        <button
          onClick={() => setHistory([])}
          className="text-xs text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200"
          title="Clear History"
        >
          Clear History
        </button>
      </div>

      {/* Calculator Display Screen */}
      <div className="bg-white dark:bg-[#181818] rounded-xl p-3 mb-3 border border-neutral-300 dark:border-neutral-800 text-right shadow-inner">
        <div className="text-xs text-neutral-400 font-mono h-4 overflow-hidden truncate">
          {expression}
        </div>
        <div className="text-3xl font-mono font-bold tracking-tight text-neutral-900 dark:text-white tabular-nums overflow-x-auto overflow-y-hidden">
          {display}
        </div>
      </div>

      {/* Keypad Grid */}
      <div className="flex-1 grid grid-cols-4 gap-2">
        {isScientific && (
          <>
            <button
              onClick={() => handleSciOp('sin')}
              className="p-2 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 dark:hover:bg-neutral-700 rounded-lg text-xs font-semibold"
            >
              sin
            </button>
            <button
              onClick={() => handleSciOp('cos')}
              className="p-2 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 dark:hover:bg-neutral-700 rounded-lg text-xs font-semibold"
            >
              cos
            </button>
            <button
              onClick={() => handleSciOp('tan')}
              className="p-2 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 dark:hover:bg-neutral-700 rounded-lg text-xs font-semibold"
            >
              tan
            </button>
            <button
              onClick={() => handleSciOp('sqrt')}
              className="p-2 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 dark:hover:bg-neutral-700 rounded-lg text-xs font-semibold"
            >
              √
            </button>
            <button
              onClick={() => handleSciOp('sqr')}
              className="p-2 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 dark:hover:bg-neutral-700 rounded-lg text-xs font-semibold"
            >
              x²
            </button>
            <button
              onClick={() => handleSciOp('ln')}
              className="p-2 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 dark:hover:bg-neutral-700 rounded-lg text-xs font-semibold"
            >
              ln
            </button>
            <button
              onClick={() => setDisplay(Math.PI.toString().slice(0, 8))}
              className="p-2 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 dark:hover:bg-neutral-700 rounded-lg text-xs font-semibold"
            >
              π
            </button>
            <button
              onClick={() => handleSciOp('1/x')}
              className="p-2 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 dark:hover:bg-neutral-700 rounded-lg text-xs font-semibold"
            >
              1/x
            </button>
          </>
        )}

        {/* Standard buttons */}
        <button
          onClick={handleClear}
          className="p-2.5 bg-neutral-300/80 dark:bg-neutral-700 text-[#E95420] font-bold rounded-lg hover:bg-neutral-300"
        >
          C
        </button>
        <button
          onClick={handleBackspace}
          className="p-2.5 bg-neutral-300/80 dark:bg-neutral-700 rounded-lg hover:bg-neutral-300 flex items-center justify-center"
        >
          <Delete className="w-4 h-4" />
        </button>
        <button
          onClick={() => handleOperator('%')}
          className="p-2.5 bg-neutral-300/80 dark:bg-neutral-700 font-semibold rounded-lg hover:bg-neutral-300"
        >
          %
        </button>
        <button
          onClick={() => handleOperator('÷')}
          className="p-2.5 bg-[#E95420]/20 text-[#E95420] font-bold text-base rounded-lg hover:bg-[#E95420]/30"
        >
          ÷
        </button>

        {['7', '8', '9'].map((d) => (
          <button
            key={d}
            onClick={() => handleDigit(d)}
            className="p-2.5 bg-white dark:bg-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-700/80 rounded-lg font-semibold text-base shadow-xs"
          >
            {d}
          </button>
        ))}
        <button
          onClick={() => handleOperator('×')}
          className="p-2.5 bg-[#E95420]/20 text-[#E95420] font-bold text-base rounded-lg hover:bg-[#E95420]/30"
        >
          ×
        </button>

        {['4', '5', '6'].map((d) => (
          <button
            key={d}
            onClick={() => handleDigit(d)}
            className="p-2.5 bg-white dark:bg-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-700/80 rounded-lg font-semibold text-base shadow-xs"
          >
            {d}
          </button>
        ))}
        <button
          onClick={() => handleOperator('-')}
          className="p-2.5 bg-[#E95420]/20 text-[#E95420] font-bold text-base rounded-lg hover:bg-[#E95420]/30"
        >
          -
        </button>

        {['1', '2', '3'].map((d) => (
          <button
            key={d}
            onClick={() => handleDigit(d)}
            className="p-2.5 bg-white dark:bg-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-700/80 rounded-lg font-semibold text-base shadow-xs"
          >
            {d}
          </button>
        ))}
        <button
          onClick={() => handleOperator('+')}
          className="p-2.5 bg-[#E95420]/20 text-[#E95420] font-bold text-base rounded-lg hover:bg-[#E95420]/30"
        >
          +
        </button>

        <button
          onClick={() => handleDigit('0')}
          className="col-span-2 p-2.5 bg-white dark:bg-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-700/80 rounded-lg font-semibold text-base shadow-xs"
        >
          0
        </button>
        <button
          onClick={() => !display.includes('.') && setDisplay(display + '.')}
          className="p-2.5 bg-white dark:bg-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-700/80 rounded-lg font-bold text-base shadow-xs"
        >
          .
        </button>
        <button
          onClick={handleCalculate}
          className="p-2.5 bg-[#E95420] text-white font-bold text-base rounded-lg hover:bg-[#d84a1b] shadow-sm flex items-center justify-center"
        >
          =
        </button>
      </div>
    </div>
  );
};
