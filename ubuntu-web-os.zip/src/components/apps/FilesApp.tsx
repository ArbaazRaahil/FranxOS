/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Folder,
  FileText,
  Image as ImageIcon,
  Music,
  Video,
  File,
  ChevronRight,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  LayoutGrid,
  List,
  Search,
  Plus,
  Trash2,
  Edit2,
  HardDrive,
  Home,
  Monitor,
  Download,
  Clock,
  Sparkles,
} from 'lucide-react';
import { mockFS } from '../../services/mockFileSystem';
import { FileItem } from '../../types/os';

interface FilesAppProps {
  onOpenFile?: (file: FileItem) => void;
  initialPath?: string;
}

export const FilesApp: React.FC<FilesAppProps> = ({ onOpenFile, initialPath = '/home/ubuntu' }) => {
  const [currentPath, setCurrentPath] = useState(initialPath);
  const [history, setHistory] = useState<string[]>([initialPath]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [files, setFiles] = useState<FileItem[]>([]);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFile, setSelectedFile] = useState<FileItem | null>(null);
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);
  const [isCreatingFile, setIsCreatingFile] = useState(false);
  const [newItemName, setNewItemName] = useState('');

  const loadContents = () => {
    if (searchQuery.trim()) {
      setFiles(mockFS.search(searchQuery));
    } else {
      setFiles(mockFS.getDirectoryContents(currentPath));
    }
  };

  useEffect(() => {
    loadContents();
    const unsub = mockFS.subscribe(loadContents);
    return () => unsub();
  }, [currentPath, searchQuery]);

  const navigateTo = (path: string) => {
    if (path === currentPath) return;
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(path);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    setCurrentPath(path);
    setSelectedFile(null);
    setSearchQuery('');
  };

  const handleBack = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setCurrentPath(history[historyIndex - 1]);
      setSelectedFile(null);
    }
  };

  const handleForward = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setCurrentPath(history[historyIndex + 1]);
      setSelectedFile(null);
    }
  };

  const handleUp = () => {
    if (currentPath === '/' || currentPath === '/home/ubuntu') return;
    const lastSlash = currentPath.lastIndexOf('/');
    const parent = lastSlash === 0 ? '/' : currentPath.substring(0, lastSlash);
    navigateTo(parent);
  };

  const handleItemDoubleClick = (item: FileItem) => {
    if (item.type === 'folder') {
      navigateTo(item.path);
    } else {
      if (onOpenFile) {
        onOpenFile(item);
      }
    }
  };

  const handleCreateFolder = (e: React.FormEvent) => {
    e.preventDefault();
    if (newItemName.trim()) {
      mockFS.createFolder(currentPath, newItemName.trim());
      setNewItemName('');
      setIsCreatingFolder(false);
    }
  };

  const handleCreateFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (newItemName.trim()) {
      mockFS.createFile(currentPath, newItemName.trim(), '# New Document\n');
      setNewItemName('');
      setIsCreatingFile(false);
    }
  };

  const handleDelete = (item: FileItem) => {
    if (window.confirm(`Delete "${item.name}"?`)) {
      mockFS.deleteItem(item.path);
      if (selectedFile?.id === item.id) setSelectedFile(null);
    }
  };

  const getFileIcon = (item: FileItem) => {
    if (item.type === 'folder') {
      return <Folder className="w-10 h-10 text-[#4a90d9] fill-[#4a90d9]/20" />;
    }
    const ext = item.extension?.toLowerCase();
    if (ext === 'txt' || ext === 'md' || ext === 'json' || ext === 'csv') {
      return <FileText className="w-10 h-10 text-neutral-400" />;
    }
    if (ext === 'svg' || ext === 'png' || ext === 'jpg' || ext === 'jpeg') {
      return <ImageIcon className="w-10 h-10 text-emerald-500" />;
    }
    if (ext === 'mp3' || ext === 'track' || ext === 'wav') {
      return <Music className="w-10 h-10 text-purple-500" />;
    }
    if (ext === 'mp4' || ext === 'webm') {
      return <Video className="w-10 h-10 text-blue-500" />;
    }
    return <File className="w-10 h-10 text-neutral-400" />;
  };

  const formatSize = (bytes?: number) => {
    if (!bytes && bytes !== 0) return '--';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
  };

  const sidebarPlaces = [
    { name: 'Home', path: '/home/ubuntu', icon: Home },
    { name: 'Desktop', path: '/home/ubuntu/Desktop', icon: Monitor },
    { name: 'Documents', path: '/home/ubuntu/Documents', icon: FileText },
    { name: 'Downloads', path: '/home/ubuntu/Downloads', icon: Download },
    { name: 'Music', path: '/home/ubuntu/Music', icon: Music },
    { name: 'Pictures', path: '/home/ubuntu/Pictures', icon: ImageIcon },
    { name: 'Videos', path: '/home/ubuntu/Videos', icon: Video },
    { name: 'Trash', path: '/home/ubuntu/.local/share/Trash', icon: Trash2 },
  ];

  // Breadcrumbs builder
  const pathParts = currentPath === '/' ? [''] : currentPath.split('/');

  return (
    <div className="w-full h-full flex flex-col bg-neutral-100 dark:bg-[#1E1E1E] text-neutral-800 dark:text-neutral-200 select-none overflow-hidden text-sm">
      {/* Nautilus Top Action Bar */}
      <div className="h-12 border-b border-neutral-300 dark:border-neutral-800 px-3 flex items-center justify-between gap-2 bg-neutral-50 dark:bg-[#252526]">
        {/* Navigation buttons */}
        <div className="flex items-center gap-1">
          <button
            onClick={handleBack}
            disabled={historyIndex === 0}
            className="p-1.5 rounded hover:bg-neutral-200 dark:hover:bg-neutral-700 disabled:opacity-30 disabled:hover:bg-transparent"
            title="Back"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <button
            onClick={handleForward}
            disabled={historyIndex >= history.length - 1}
            className="p-1.5 rounded hover:bg-neutral-200 dark:hover:bg-neutral-700 disabled:opacity-30 disabled:hover:bg-transparent"
            title="Forward"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={handleUp}
            disabled={currentPath === '/' || currentPath === '/home/ubuntu'}
            className="p-1.5 rounded hover:bg-neutral-200 dark:hover:bg-neutral-700 disabled:opacity-30 disabled:hover:bg-transparent"
            title="Parent Folder"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

        {/* Path Breadcrumbs */}
        <div className="flex-1 max-w-md flex items-center bg-white dark:bg-[#2F2F2F] border border-neutral-300 dark:border-neutral-700 rounded-md px-2 py-1 overflow-x-auto text-xs">
          <button
            onClick={() => navigateTo('/home/ubuntu')}
            className="px-1.5 py-0.5 rounded hover:bg-neutral-200 dark:hover:bg-neutral-600 font-medium"
          >
            ubuntu
          </button>
          {pathParts.map((part, index) => {
            if (!part || part === 'home' || part === 'ubuntu') return null;
            const fullSubPath = pathParts.slice(0, index + 1).join('/');
            return (
              <React.Fragment key={index}>
                <ChevronRight className="w-3.5 h-3.5 text-neutral-400 mx-0.5 shrink-0" />
                <button
                  onClick={() => navigateTo(fullSubPath)}
                  className="px-1.5 py-0.5 rounded hover:bg-neutral-200 dark:hover:bg-neutral-600 font-medium whitespace-nowrap"
                >
                  {part}
                </button>
              </React.Fragment>
            );
          })}
        </div>

        {/* Search, View mode, and Actions */}
        <div className="flex items-center gap-1.5">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-2" />
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-32 focus:w-44 transition-all duration-200 pl-7 pr-2 py-1 text-xs rounded-md bg-white dark:bg-[#2F2F2F] border border-neutral-300 dark:border-neutral-700 outline-none focus:border-[#E95420]"
            />
          </div>

          <div className="flex bg-neutral-200 dark:bg-neutral-700 p-0.5 rounded-md">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1 rounded ${viewMode === 'grid' ? 'bg-white dark:bg-neutral-600 shadow-xs' : ''}`}
              title="Grid View"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1 rounded ${viewMode === 'list' ? 'bg-white dark:bg-neutral-600 shadow-xs' : ''}`}
              title="List View"
            >
              <List className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* New folder button */}
          <button
            onClick={() => {
              setIsCreatingFolder(true);
              setIsCreatingFile(false);
              setNewItemName('');
            }}
            className="px-2 py-1 text-xs bg-neutral-200 dark:bg-neutral-700 hover:bg-neutral-300 dark:hover:bg-neutral-600 rounded flex items-center gap-1 font-medium"
            title="Create New Folder"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Folder</span>
          </button>

          {/* New file button */}
          <button
            onClick={() => {
              setIsCreatingFile(true);
              setIsCreatingFolder(false);
              setNewItemName('');
            }}
            className="px-2 py-1 text-xs bg-[#E95420] text-white hover:bg-[#d84a1b] rounded flex items-center gap-1 font-medium shadow-xs"
            title="Create New File"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Doc</span>
          </button>
        </div>
      </div>

      {/* Main Body with Sidebar + File Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar */}
        <div className="w-48 bg-neutral-100 dark:bg-[#1E1E1E] border-r border-neutral-300 dark:border-neutral-800 p-2 flex flex-col justify-between shrink-0">
          <div className="space-y-0.5">
            <div className="text-[11px] font-bold text-neutral-400 dark:text-neutral-500 uppercase px-2.5 py-1 tracking-wider">
              Places
            </div>
            {sidebarPlaces.map((place) => {
              const Icon = place.icon;
              const isActive = currentPath === place.path;
              return (
                <button
                  key={place.path}
                  onClick={() => navigateTo(place.path)}
                  className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors text-left ${
                    isActive
                      ? 'bg-[#E95420]/15 text-[#E95420] dark:bg-[#E95420]/25 dark:text-[#FFA447] font-semibold'
                      : 'hover:bg-neutral-200 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#E95420]' : 'text-neutral-500'}`} />
                  <span>{place.name}</span>
                </button>
              );
            })}
          </div>

          <div className="p-2 border-t border-neutral-300 dark:border-neutral-800 text-[11px] text-neutral-500">
            <div className="flex items-center gap-1.5 mb-1">
              <HardDrive className="w-3.5 h-3.5" />
              <span>Ubuntu Storage</span>
            </div>
            <div className="w-full bg-neutral-200 dark:bg-neutral-700 h-1.5 rounded-full overflow-hidden">
              <div className="bg-[#E95420] h-full w-[24%]" />
            </div>
            <div className="text-[10px] mt-1 text-neutral-400">12.4 GB available of 64 GB</div>
          </div>
        </div>

        {/* Content Explorer Area */}
        <div
          onClick={() => setSelectedFile(null)}
          className="flex-1 p-4 overflow-y-auto bg-white dark:bg-[#181818] relative"
        >
          {/* Creation Modal / Inline Form */}
          {(isCreatingFolder || isCreatingFile) && (
            <div
              onClick={(e) => e.stopPropagation()}
              className="mb-4 p-3 bg-neutral-100 dark:bg-[#252526] border border-[#E95420] rounded-lg max-w-sm shadow-md"
            >
              <form onSubmit={isCreatingFolder ? handleCreateFolder : handleCreateFile}>
                <div className="text-xs font-semibold mb-2">
                  {isCreatingFolder ? 'Create New Folder' : 'Create New Document'}
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    autoFocus
                    placeholder={isCreatingFolder ? 'Folder name' : 'document.txt'}
                    value={newItemName}
                    onChange={(e) => setNewItemName(e.target.value)}
                    className="flex-1 px-2.5 py-1 text-xs rounded border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 outline-none focus:border-[#E95420]"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1 text-xs bg-[#E95420] text-white rounded font-medium hover:bg-[#d84a1b]"
                  >
                    Create
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsCreatingFolder(false);
                      setIsCreatingFile(false);
                    }}
                    className="px-2 py-1 text-xs text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          {files.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-neutral-400 text-center">
              <Folder className="w-16 h-16 stroke-1 text-neutral-300 dark:text-neutral-700 mb-2" />
              <p className="text-sm font-medium">This folder is empty</p>
              <p className="text-xs text-neutral-400 mt-0.5">
                Right-click or use the top buttons to create files
              </p>
            </div>
          ) : viewMode === 'grid' ? (
            /* Grid View */
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
              {files.map((item) => {
                const isSelected = selectedFile?.id === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedFile(item);
                    }}
                    onDoubleClick={() => handleItemDoubleClick(item)}
                    className={`flex flex-col items-center p-3 rounded-lg cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-[#E95420]/20 border border-[#E95420]/60 dark:bg-[#E95420]/30'
                        : 'hover:bg-neutral-100 dark:hover:bg-neutral-800 border border-transparent'
                    }`}
                  >
                    <div className="mb-2 relative flex items-center justify-center h-12 w-12">
                      {getFileIcon(item)}
                    </div>
                    <span className="text-xs font-medium text-center truncate w-full px-1">
                      {item.name}
                    </span>
                    <span className="text-[10px] text-neutral-400 mt-0.5">
                      {item.type === 'folder' ? 'Folder' : formatSize(item.size)}
                    </span>
                  </div>
                );
              })}
            </div>
          ) : (
            /* List View */
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-neutral-200 dark:border-neutral-800 text-neutral-400 pb-2">
                  <th className="py-2 px-3 font-semibold">Name</th>
                  <th className="py-2 px-3 font-semibold w-24">Size</th>
                  <th className="py-2 px-3 font-semibold w-28">Type</th>
                  <th className="py-2 px-3 font-semibold w-36">Modified</th>
                  <th className="py-2 px-3 font-semibold w-16 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800/60">
                {files.map((item) => {
                  const isSelected = selectedFile?.id === item.id;
                  return (
                    <tr
                      key={item.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedFile(item);
                      }}
                      onDoubleClick={() => handleItemDoubleClick(item)}
                      className={`cursor-pointer transition-colors ${
                        isSelected
                          ? 'bg-[#E95420]/15 dark:bg-[#E95420]/25'
                          : 'hover:bg-neutral-50 dark:hover:bg-neutral-800/50'
                      }`}
                    >
                      <td className="py-2 px-3 flex items-center gap-2 font-medium">
                        <span className="shrink-0">{getFileIcon(item)}</span>
                        <span className="truncate">{item.name}</span>
                      </td>
                      <td className="py-2 px-3 text-neutral-400 tabular-nums">
                        {item.type === 'folder' ? '--' : formatSize(item.size)}
                      </td>
                      <td className="py-2 px-3 text-neutral-400 capitalize">
                        {item.type === 'folder' ? 'Folder' : item.extension || 'File'}
                      </td>
                      <td className="py-2 px-3 text-neutral-400 tabular-nums">{item.updatedAt}</td>
                      <td className="py-2 px-3 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDelete(item);
                          }}
                          className="p-1 text-neutral-400 hover:text-red-500 rounded"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Bottom Status bar */}
      <div className="h-7 border-t border-neutral-300 dark:border-neutral-800 px-3 flex items-center justify-between text-[11px] text-neutral-500 bg-neutral-100 dark:bg-[#1E1E1E]">
        <div>
          {files.length} item{files.length === 1 ? '' : 's'}
          {selectedFile && ` · Selected: ${selectedFile.name}`}
        </div>
        <div>Free space: 51.6 GB</div>
      </div>
    </div>
  );
};
