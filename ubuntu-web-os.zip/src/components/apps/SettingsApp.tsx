/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Palette,
  Layout,
  Volume2,
  Monitor,
  Info,
  Moon,
  Sun,
  Check,
  RotateCcw,
  VolumeX,
} from 'lucide-react';
import { SystemSettings } from '../../types/os';
import { ACCENT_COLORS, WALLPAPERS } from '../../data/appsData';
import { soundService } from '../../services/soundEffects';
import { mockFS } from '../../services/mockFileSystem';

interface SettingsAppProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
}

export const SettingsApp: React.FC<SettingsAppProps> = ({ settings, onUpdateSettings }) => {
  const [activeTab, setActiveTab] = useState<'appearance' | 'dock' | 'sound' | 'display' | 'about'>('appearance');

  const navItems = [
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'dock', label: 'Ubuntu Desktop', icon: Layout },
    { id: 'sound', label: 'Sound', icon: Volume2 },
    { id: 'display', label: 'Displays', icon: Monitor },
    { id: 'about', label: 'About', icon: Info },
  ] as const;

  return (
    <div className="w-full h-full flex bg-neutral-100 dark:bg-[#1E1E1E] text-neutral-800 dark:text-neutral-200 text-sm overflow-hidden select-none">
      {/* Left Sidebar */}
      <div className="w-52 bg-neutral-50 dark:bg-[#252526] border-r border-neutral-300 dark:border-neutral-800 p-3 flex flex-col justify-between shrink-0">
        <div className="space-y-1">
          <div className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider px-3 py-1.5">
            Settings
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-semibold text-left transition-colors ${
                  isActive
                    ? 'bg-[#E95420] text-white shadow-xs'
                    : 'hover:bg-neutral-200 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        <div className="text-[10px] text-neutral-400 px-3">Ubuntu 24.04 LTS (Noble Numbat)</div>
      </div>

      {/* Main Settings Panel */}
      <div className="flex-1 p-6 overflow-y-auto bg-white dark:bg-[#181818]">
        {/* Appearance Tab */}
        {activeTab === 'appearance' && (
          <div className="max-w-xl space-y-6">
            <div>
              <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-white">
                Appearance
              </h2>
              <p className="text-xs text-neutral-500 mt-0.5">Customize style, accents, and wallpapers</p>
            </div>

            {/* Dark / Light Style Selection */}
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                Style
              </label>
              <div className="grid grid-cols-2 gap-4">
                <div
                  onClick={() => onUpdateSettings({ theme: 'light' })}
                  className={`p-3 rounded-xl border-2 cursor-pointer transition-all flex flex-col items-center gap-2 ${
                    settings.theme === 'light'
                      ? 'border-[#E95420] bg-neutral-50 shadow-xs'
                      : 'border-neutral-200 hover:border-neutral-300'
                  }`}
                >
                  <div className="w-full h-16 rounded-lg bg-neutral-100 border border-neutral-300 flex items-center justify-center">
                    <Sun className="w-8 h-8 text-amber-500" />
                  </div>
                  <span className="text-xs font-semibold">Light</span>
                </div>

                <div
                  onClick={() => onUpdateSettings({ theme: 'dark' })}
                  className={`p-3 rounded-xl border-2 cursor-pointer transition-all flex flex-col items-center gap-2 ${
                    settings.theme === 'dark'
                      ? 'border-[#E95420] bg-neutral-900 shadow-xs text-white'
                      : 'border-neutral-700 hover:border-neutral-600'
                  }`}
                >
                  <div className="w-full h-16 rounded-lg bg-[#252526] border border-neutral-700 flex items-center justify-center">
                    <Moon className="w-8 h-8 text-[#E95420]" />
                  </div>
                  <span className="text-xs font-semibold">Dark</span>
                </div>
              </div>
            </div>

            {/* Yaru Accent Color */}
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                Accent Color
              </label>
              <div className="grid grid-cols-5 gap-3">
                {ACCENT_COLORS.map((accent) => {
                  const isSelected = settings.accentColor === accent.color;
                  return (
                    <button
                      key={accent.color}
                      onClick={() =>
                        onUpdateSettings({ accentColor: accent.color, accentName: accent.name })
                      }
                      className="flex flex-col items-center gap-1.5 p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                      title={accent.name}
                    >
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center shadow-xs text-white"
                        style={{ backgroundColor: accent.color }}
                      >
                        {isSelected && <Check className="w-4 h-4 stroke-[3]" />}
                      </div>
                      <span className="text-[10px] text-neutral-500 text-center truncate w-full">
                        {accent.name.split(' ')[0]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Background / Wallpaper */}
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                Background
              </label>
              <div className="grid grid-cols-3 gap-3">
                {WALLPAPERS.map((wp) => {
                  const isSelected = settings.wallpaper === wp.css;
                  return (
                    <div
                      key={wp.id}
                      onClick={() => onUpdateSettings({ wallpaper: wp.css, wallpaperName: wp.name })}
                      className={`h-24 rounded-xl cursor-pointer overflow-hidden border-2 relative transition-all shadow-xs ${
                        isSelected ? 'border-[#E95420] ring-2 ring-[#E95420]/30' : 'border-neutral-300 dark:border-neutral-700'
                      }`}
                      style={{ background: wp.css }}
                    >
                      {isSelected && (
                        <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-[#E95420] text-white flex items-center justify-center">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                      <div className="absolute inset-x-0 bottom-0 bg-black/60 backdrop-blur-xs p-1.5 text-[10px] text-white font-medium truncate">
                        {wp.name}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Ubuntu Desktop / Dock Tab */}
        {activeTab === 'dock' && (
          <div className="max-w-xl space-y-6">
            <div>
              <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-white">
                Ubuntu Desktop & Dock
              </h2>
              <p className="text-xs text-neutral-500 mt-0.5">Customize the left dock and desktop icons</p>
            </div>

            {/* Position */}
            <div className="p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
              <div>
                <h4 className="font-semibold text-xs text-neutral-900 dark:text-white">Dock Position on Screen</h4>
                <p className="text-[11px] text-neutral-400 mt-0.5">Place dock on left edge or bottom</p>
              </div>
              <div className="flex bg-neutral-200 dark:bg-neutral-800 p-0.5 rounded-lg text-xs font-semibold">
                <button
                  onClick={() => onUpdateSettings({ dockPosition: 'left' })}
                  className={`px-3 py-1 rounded-md transition-colors ${
                    settings.dockPosition === 'left' ? 'bg-[#E95420] text-white shadow-xs' : 'text-neutral-500'
                  }`}
                >
                  Left
                </button>
                <button
                  onClick={() => onUpdateSettings({ dockPosition: 'bottom' })}
                  className={`px-3 py-1 rounded-md transition-colors ${
                    settings.dockPosition === 'bottom' ? 'bg-[#E95420] text-white shadow-xs' : 'text-neutral-500'
                  }`}
                >
                  Bottom
                </button>
              </div>
            </div>

            {/* Icon Size */}
            <div className="p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 space-y-2">
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="font-semibold text-xs text-neutral-900 dark:text-white">Icon Size</h4>
                  <p className="text-[11px] text-neutral-400 mt-0.5">Size of app icons in the launcher</p>
                </div>
                <span className="font-mono text-xs font-semibold">{settings.dockIconSize}px</span>
              </div>
              <input
                type="range"
                min="36"
                max="64"
                step="4"
                value={settings.dockIconSize}
                onChange={(e) => onUpdateSettings({ dockIconSize: Number(e.target.value) })}
                className="w-full accent-[#E95420]"
              />
            </div>

            {/* Auto-hide */}
            <div className="p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
              <div>
                <h4 className="font-semibold text-xs text-neutral-900 dark:text-white">Auto-hide the Dock</h4>
                <p className="text-[11px] text-neutral-400 mt-0.5">The dock hides when any window overlaps it</p>
              </div>
              <button
                onClick={() => onUpdateSettings({ dockAutoHide: !settings.dockAutoHide })}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  settings.dockAutoHide ? 'bg-[#E95420]' : 'bg-neutral-300 dark:bg-neutral-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.dockAutoHide ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Show Desktop Icons */}
            <div className="p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
              <div>
                <h4 className="font-semibold text-xs text-neutral-900 dark:text-white">Desktop Icons</h4>
                <p className="text-[11px] text-neutral-400 mt-0.5">Show personal Home and files on desktop background</p>
              </div>
              <button
                onClick={() => onUpdateSettings({ showDesktopIcons: !settings.showDesktopIcons })}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  settings.showDesktopIcons ? 'bg-[#E95420]' : 'bg-neutral-300 dark:bg-neutral-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.showDesktopIcons ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        )}

        {/* Sound Tab */}
        {activeTab === 'sound' && (
          <div className="max-w-xl space-y-6">
            <div>
              <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-white">Sound</h2>
              <p className="text-xs text-neutral-500 mt-0.5">Configure audio levels and test speakers</p>
            </div>

            <div className="p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 space-y-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onUpdateSettings({ isMuted: !settings.isMuted })}
                    className="p-1 hover:text-[#E95420]"
                  >
                    {settings.isMuted ? <VolumeX className="w-5 h-5 text-red-500" /> : <Volume2 className="w-5 h-5" />}
                  </button>
                  <span className="font-semibold text-xs">Master Volume</span>
                </div>
                <span className="font-mono text-xs">{settings.isMuted ? 'Muted' : `${settings.volume}%`}</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.isMuted ? 0 : settings.volume}
                onChange={(e) => onUpdateSettings({ volume: Number(e.target.value), isMuted: false })}
                className="w-full accent-[#E95420]"
              />
              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => soundService.playTestChime()}
                  className="px-3 py-1.5 bg-[#E95420] text-white rounded-lg text-xs font-semibold hover:bg-[#d84a1b]"
                >
                  Test Audio Chime
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Display Tab */}
        {activeTab === 'display' && (
          <div className="max-w-xl space-y-6">
            <div>
              <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-white">Displays</h2>
              <p className="text-xs text-neutral-500 mt-0.5">Display resolution and Night Light filter</p>
            </div>

            <div className="p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="font-semibold text-xs text-neutral-900 dark:text-white">Night Light</h4>
                  <p className="text-[11px] text-neutral-400 mt-0.5">
                    Warmer screen colors reduce eye strain at night
                  </p>
                </div>
                <button
                  onClick={() => onUpdateSettings({ nightLight: !settings.nightLight })}
                  className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                    settings.nightLight ? 'bg-[#E95420]' : 'bg-neutral-300 dark:bg-neutral-700'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${
                      settings.nightLight ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {settings.nightLight && (
                <div className="pt-2 border-t border-neutral-200 dark:border-neutral-800">
                  <div className="flex justify-between text-xs mb-1">
                    <span>Color Temperature Warmth</span>
                    <span>{settings.nightLightWarmth}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="60"
                    value={settings.nightLightWarmth}
                    onChange={(e) => onUpdateSettings({ nightLightWarmth: Number(e.target.value) })}
                    className="w-full accent-[#E95420]"
                  />
                </div>
              )}
            </div>

            <div className="p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
              <div>
                <h4 className="font-semibold text-xs text-neutral-900 dark:text-white">Active Screen Resolution</h4>
                <p className="text-[11px] text-neutral-400 mt-0.5">Viewport scaled hardware canvas</p>
              </div>
              <span className="font-mono text-xs font-semibold px-2 py-1 bg-neutral-100 dark:bg-neutral-800 rounded">
                1920 × 1080 (16:9)
              </span>
            </div>
          </div>
        )}

        {/* About Tab */}
        {activeTab === 'about' && (
          <div className="max-w-xl space-y-6">
            <div className="flex items-center gap-4 border-b border-neutral-200 dark:border-neutral-800 pb-6">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#E95420] to-[#772953] flex items-center justify-center text-white text-3xl font-bold shadow-md">
                U
              </div>
              <div>
                <h2 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
                  Ubuntu 24.04 LTS
                </h2>
                <p className="text-xs text-neutral-500 mt-0.5">Noble Numbat · 64-bit Edition</p>
              </div>
            </div>

            <div className="divide-y divide-neutral-200 dark:divide-neutral-800 text-xs">
              <div className="py-2.5 flex justify-between">
                <span className="text-neutral-500">Hardware Model</span>
                <span className="font-medium text-neutral-900 dark:text-neutral-100">
                  Web Browser Virtual Machine
                </span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-neutral-500">Memory</span>
                <span className="font-medium text-neutral-900 dark:text-neutral-100">16.0 GiB</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-neutral-500">Processor</span>
                <span className="font-medium text-neutral-900 dark:text-neutral-100">
                  Octa-Core Virtual CPU @ 3.40GHz
                </span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-neutral-500">Graphics</span>
                <span className="font-medium text-neutral-900 dark:text-neutral-100">
                  WebGL 2.0 Hardware Accelerated
                </span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-neutral-500">Disk Capacity</span>
                <span className="font-medium text-neutral-900 dark:text-neutral-100">64.0 GB</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-neutral-500">OS Name</span>
                <span className="font-medium text-neutral-900 dark:text-neutral-100">
                  Ubuntu 24.04 LTS
                </span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-neutral-500">GNOME Version</span>
                <span className="font-medium text-neutral-900 dark:text-neutral-100">46.0</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-neutral-500">Windowing System</span>
                <span className="font-medium text-neutral-900 dark:text-neutral-100">
                  Mutter (HTML5 Compositor)
                </span>
              </div>
            </div>

            <div className="pt-4 border-t border-neutral-200 dark:border-neutral-800">
              <button
                onClick={() => {
                  if (window.confirm('Reset file system to initial factory state?')) {
                    mockFS.resetToDefault();
                  }
                }}
                className="px-3.5 py-2 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-200 rounded-lg text-xs font-semibold flex items-center gap-2"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restore Default File System</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
