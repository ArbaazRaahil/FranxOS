/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Save,
  FileText,
  Eye,
  Code,
  Copy,
  Check,
  Search,
  FolderOpen,
  Plus,
  X,
} from 'lucide-react';
import { mockFS } from '../../services/mockFileSystem';
import { FileItem } from '../../types/os';

interface EditorAppProps {
  initialFile?: FileItem | null;
}

interface OpenDoc {
  id: string;
  name: string;
  path?: string;
  content: string;
  isModified: boolean;
}

export const EditorApp: React.FC<EditorAppProps> = ({ initialFile }) => {
  const [docs, setDocs] = useState<OpenDoc[]>([
    {
      id: 'default',
      name: 'Untitled Document 1',
      content: '# Welcome to Ubuntu Gedit Text Editor\n\nYou can write notes, markdown docs, or system scripts here.\n- Line numbers enabled\n- Split markdown preview\n- Auto word and char counters\n- Save directly to Ubuntu Filesystem!\n',
      isModified: false,
    },
  ]);
  const [activeDocId, setActiveDocId] = useState('default');
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [showFind, setShowFind] = useState(false);
  const [findQuery, setFindQuery] = useState('');
  const [saveToast, setSaveToast] = useState(false);

  // If opened with initial file from Files or Terminal
  useEffect(() => {
    if (initialFile && initialFile.type === 'file') {
      const existing = docs.find((d) => d.path === initialFile.path);
      if (existing) {
        setActiveDocId(existing.id);
      } else {
        const newDoc: OpenDoc = {
          id: Math.random().toString(),
          name: initialFile.name,
          path: initialFile.path,
          content: initialFile.content || '',
          isModified: false,
        };
        setDocs((prev) => [...prev, newDoc]);
        setActiveDocId(newDoc.id);
      }
    }
  }, [initialFile]);

  const activeDoc = docs.find((d) => d.id === activeDocId) || docs[0];

  const handleContentChange = (newContent: string) => {
    setDocs((prev) =>
      prev.map((d) => (d.id === activeDocId ? { ...d, content: newContent, isModified: true } : d))
    );
  };

  const handleSave = () => {
    if (!activeDoc) return;
    if (activeDoc.path) {
      mockFS.updateFileContent(activeDoc.path, activeDoc.content);
      setDocs((prev) =>
        prev.map((d) => (d.id === activeDocId ? { ...d, isModified: false } : d))
      );
    } else {
      // Save to desktop
      const fileName = activeDoc.name.endsWith('.txt') || activeDoc.name.endsWith('.md')
        ? activeDoc.name
        : `${activeDoc.name}.txt`;
      const created = mockFS.createFile('/home/ubuntu/Desktop', fileName, activeDoc.content);
      setDocs((prev) =>
        prev.map((d) =>
          d.id === activeDocId
            ? { ...d, path: created.path, name: created.name, isModified: false }
            : d
        )
      );
    }
    setSaveToast(true);
    setTimeout(() => setSaveToast(false), 2000);
  };

  const handleNewTab = () => {
    const newDoc: OpenDoc = {
      id: Math.random().toString(),
      name: `Untitled ${docs.length + 1}`,
      content: '',
      isModified: false,
    };
    setDocs((prev) => [...prev, newDoc]);
    setActiveDocId(newDoc.id);
  };

  const handleCloseTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (docs.length === 1) {
      // Keep at least one empty doc
      setDocs([
        {
          id: Math.random().toString(),
          name: 'Untitled 1',
          content: '',
          isModified: false,
        },
      ]);
      return;
    }
    const filtered = docs.filter((d) => d.id !== id);
    setDocs(filtered);
    if (activeDocId === id) {
      setActiveDocId(filtered[0].id);
    }
  };

  const lines = (activeDoc?.content || '').split('\n');
  const wordCount = (activeDoc?.content || '').trim() ? (activeDoc?.content || '').trim().split(/\s+/).length : 0;
  const charCount = (activeDoc?.content || '').length;

  return (
    <div className="w-full h-full flex flex-col bg-white dark:bg-[#1E1E1E] text-neutral-800 dark:text-neutral-200 text-sm overflow-hidden select-text">
      {/* Top Toolbar */}
      <div className="h-10 border-b border-neutral-300 dark:border-neutral-800 px-3 flex items-center justify-between bg-neutral-100 dark:bg-[#252526] select-none">
        {/* Document Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto flex-1 mr-2">
          {docs.map((doc) => {
            const isActive = doc.id === activeDocId;
            return (
              <div
                key={doc.id}
                onClick={() => setActiveDocId(doc.id)}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-t text-xs font-medium cursor-pointer transition-colors ${
                  isActive
                    ? 'bg-white dark:bg-[#1E1E1E] border-t-2 border-[#E95420] text-neutral-900 dark:text-white shadow-xs'
                    : 'hover:bg-neutral-200 dark:hover:bg-neutral-700/60 text-neutral-500'
                }`}
              >
                <FileText className="w-3.5 h-3.5 text-[#E95420]" />
                <span className="max-w-[120px] truncate">
                  {doc.name}
                  {doc.isModified ? ' *' : ''}
                </span>
                <button
                  onClick={(e) => handleCloseTab(doc.id, e)}
                  className="p-0.5 rounded-full hover:bg-neutral-300 dark:hover:bg-neutral-600 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            );
          })}
          <button
            onClick={handleNewTab}
            className="p-1 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded text-neutral-500"
            title="New File"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => setShowFind(!showFind)}
            className={`p-1.5 rounded text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700 ${
              showFind ? 'bg-neutral-200 dark:bg-neutral-700' : ''
            }`}
            title="Find"
          >
            <Search className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsPreviewOpen(!isPreviewOpen)}
            className={`p-1.5 rounded text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700 ${
              isPreviewOpen ? 'bg-neutral-200 dark:bg-neutral-700' : ''
            }`}
            title="Markdown Preview"
          >
            <Eye className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleSave}
            className="px-2.5 py-1 bg-[#E95420] hover:bg-[#d84a1b] text-white rounded text-xs flex items-center gap-1 font-medium shadow-xs"
            title="Save file (Ctrl+S)"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{saveToast ? 'Saved!' : 'Save'}</span>
          </button>
        </div>
      </div>

      {/* Find Bar */}
      {showFind && (
        <div className="px-3 py-1.5 bg-neutral-100 dark:bg-[#2B2B2B] border-b border-neutral-300 dark:border-neutral-700 flex items-center gap-2 select-none text-xs">
          <Search className="w-3.5 h-3.5 text-neutral-400" />
          <input
            type="text"
            placeholder="Find in text..."
            value={findQuery}
            onChange={(e) => setFindQuery(e.target.value)}
            className="px-2 py-0.5 rounded border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 outline-none w-48 text-xs"
          />
          {findQuery && (
            <span className="text-[11px] text-neutral-400">
              {((activeDoc?.content || '').match(new RegExp(findQuery, 'gi')) || []).length} match(es)
            </span>
          )}
          <button
            onClick={() => setShowFind(false)}
            className="ml-auto text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Editor Main Surface */}
      <div className="flex-1 flex overflow-hidden">
        {/* Line numbers gutter */}
        <div className="w-12 bg-neutral-50 dark:bg-[#1E1E1E] border-r border-neutral-200 dark:border-neutral-800 text-neutral-400 text-right pr-2 pt-3 select-none text-xs font-mono">
          {lines.map((_, i) => (
            <div key={i} className="leading-6">
              {i + 1}
            </div>
          ))}
        </div>

        {/* Textarea */}
        <div className="flex-1 relative overflow-auto">
          <textarea
            value={activeDoc?.content || ''}
            onChange={(e) => handleContentChange(e.target.value)}
            spellCheck={false}
            className="w-full h-full p-3 font-mono text-xs leading-6 outline-none bg-transparent resize-none border-none text-neutral-800 dark:text-neutral-100"
            style={{ fontFamily: "'Ubuntu Mono', monospace" }}
            placeholder="Type your text or code here..."
          />
        </div>

        {/* Live Markdown Preview Sidebar */}
        {isPreviewOpen && (
          <div className="w-1/2 border-l border-neutral-300 dark:border-neutral-800 p-4 overflow-y-auto bg-neutral-50 dark:bg-[#181818] prose dark:prose-invert max-w-none text-xs">
            <div className="text-[11px] font-bold text-[#E95420] uppercase tracking-wider mb-2 border-b border-neutral-200 dark:border-neutral-800 pb-1 flex items-center justify-between">
              <span>Preview</span>
              <span className="text-[10px] text-neutral-400 font-normal">Markdown Formatted</span>
            </div>
            <div className="space-y-2 leading-relaxed">
              {(activeDoc?.content || '').split('\n').map((line, idx) => {
                if (line.startsWith('# ')) {
                  return <h1 key={idx} className="text-lg font-bold text-neutral-900 dark:text-white mt-2">{line.replace('# ', '')}</h1>;
                }
                if (line.startsWith('## ')) {
                  return <h2 key={idx} className="text-base font-semibold text-neutral-800 dark:text-neutral-100 mt-2">{line.replace('## ', '')}</h2>;
                }
                if (line.startsWith('- ')) {
                  return <li key={idx} className="ml-4 list-disc text-neutral-700 dark:text-neutral-300">{line.replace('- ', '')}</li>;
                }
                if (!line.trim()) {
                  return <div key={idx} className="h-2" />;
                }
                return <p key={idx} className="text-neutral-700 dark:text-neutral-300">{line}</p>;
              })}
            </div>
          </div>
        )}
      </div>

      {/* Status Bar */}
      <div className="h-6 border-t border-neutral-300 dark:border-neutral-800 px-3 flex items-center justify-between text-[11px] text-neutral-500 bg-neutral-100 dark:bg-[#252526] select-none">
        <div className="flex items-center gap-3">
          <span>{activeDoc?.path || 'Unsaved'}</span>
          <span>·</span>
          <span>UTF-8</span>
          <span>·</span>
          <span>Plain Text / Markdown</span>
        </div>
        <div className="flex items-center gap-3 tabular-nums">
          <span>{lines.length} lines</span>
          <span>{wordCount} words</span>
          <span>{charCount} chars</span>
        </div>
      </div>
    </div>
  );
};
