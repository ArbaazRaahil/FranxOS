/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Home,
  Lock,
  Search,
  Star,
  Plus,
  X,
  ExternalLink,
  BookOpen,
  Globe,
} from 'lucide-react';

interface Tab {
  id: string;
  title: string;
  url: string;
}

export const BrowserApp: React.FC = () => {
  const [tabs, setTabs] = useState<Tab[]>([
    {
      id: '1',
      title: 'Ubuntu 24.04 LTS (Noble Numbat)',
      url: 'https://ubuntu.com/noble-numbat',
    },
    {
      id: '2',
      title: 'Hacker News Tech Feed',
      url: 'https://news.ycombinator.com',
    },
  ]);
  const [activeTabId, setActiveTabId] = useState('1');
  const [inputUrl, setInputUrl] = useState('https://ubuntu.com/noble-numbat');
  const [wikiSearch, setWikiSearch] = useState('');
  const [activeWikiTopic, setActiveWikiTopic] = useState<'ubuntu' | 'linus' | 'gnome' | 'kernel'>('ubuntu');

  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  const handleNavigate = (targetUrl: string, title?: string) => {
    let finalUrl = targetUrl.trim();
    if (!finalUrl.startsWith('http://') && !finalUrl.startsWith('https://')) {
      finalUrl = `https://${finalUrl}`;
    }
    setInputUrl(finalUrl);
    setTabs((prev) =>
      prev.map((t) =>
        t.id === activeTabId
          ? { ...t, url: finalUrl, title: title || finalUrl.replace(/^https?:\/\//, '') }
          : t
      )
    );
  };

  const handleNewTab = () => {
    const newTab: Tab = {
      id: Math.random().toString(),
      title: 'New Tab',
      url: 'https://duckduckgo.com',
    };
    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(newTab.id);
    setInputUrl(newTab.url);
  };

  const handleCloseTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) return;
    const remaining = tabs.filter((t) => t.id !== id);
    setTabs(remaining);
    if (activeTabId === id) {
      setActiveTabId(remaining[0].id);
      setInputUrl(remaining[0].url);
    }
  };

  const switchTab = (tab: Tab) => {
    setActiveTabId(tab.id);
    setInputUrl(tab.url);
  };

  return (
    <div className="w-full h-full flex flex-col bg-white dark:bg-[#1E1E1E] text-neutral-800 dark:text-neutral-200 text-sm overflow-hidden select-none">
      {/* Tab Strip */}
      <div className="h-9 bg-neutral-200 dark:bg-[#181818] flex items-center px-2 gap-1 border-b border-neutral-300 dark:border-neutral-800 overflow-x-auto">
        {tabs.map((tab) => {
          const isActive = tab.id === activeTabId;
          return (
            <div
              key={tab.id}
              onClick={() => switchTab(tab)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-t-md text-xs font-medium cursor-pointer max-w-[200px] truncate transition-colors ${
                isActive
                  ? 'bg-neutral-50 dark:bg-[#252526] text-neutral-900 dark:text-white shadow-xs'
                  : 'hover:bg-neutral-300/60 dark:hover:bg-neutral-800/80 text-neutral-600 dark:text-neutral-400'
              }`}
            >
              <Globe className="w-3.5 h-3.5 text-[#E95420] shrink-0" />
              <span className="truncate flex-1">{tab.title}</span>
              <button
                onClick={(e) => handleCloseTab(tab.id, e)}
                className="p-0.5 rounded-full hover:bg-neutral-300 dark:hover:bg-neutral-600 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          );
        })}
        <button
          onClick={handleNewTab}
          className="p-1 hover:bg-neutral-300 dark:hover:bg-neutral-800 rounded text-neutral-600 dark:text-neutral-400"
          title="New Tab"
        >
          <Plus className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Navigation Toolbar */}
      <div className="h-11 bg-neutral-50 dark:bg-[#252526] border-b border-neutral-300 dark:border-neutral-800 px-3 flex items-center gap-2">
        <button
          onClick={() => handleNavigate('https://ubuntu.com')}
          className="p-1.5 rounded hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-600 dark:text-neutral-300"
          title="Home"
        >
          <Home className="w-4 h-4" />
        </button>
        <button
          onClick={() => handleNavigate(inputUrl)}
          className="p-1.5 rounded hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-600 dark:text-neutral-300"
          title="Reload"
        >
          <RotateCw className="w-4 h-4" />
        </button>

        {/* Address Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleNavigate(inputUrl);
          }}
          className="flex-1 flex items-center bg-white dark:bg-[#1E1E1E] border border-neutral-300 dark:border-neutral-700 rounded-full px-3 py-1 focus-within:border-[#E95420] focus-within:ring-1 focus-within:ring-[#E95420]/30 transition-all"
        >
          <Lock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-500 mr-2 shrink-0" />
          <input
            type="text"
            value={inputUrl}
            onChange={(e) => setInputUrl(e.target.value)}
            className="flex-1 bg-transparent border-none outline-none text-xs text-neutral-800 dark:text-neutral-100 select-text"
            placeholder="Search or enter web address"
          />
          <Star className="w-3.5 h-3.5 text-neutral-400 hover:text-amber-500 cursor-pointer ml-2" />
        </form>
      </div>

      {/* Bookmarks Bar */}
      <div className="h-7 bg-neutral-100 dark:bg-[#1F1F1F] border-b border-neutral-200 dark:border-neutral-800 px-3 flex items-center gap-3 text-xs text-neutral-600 dark:text-neutral-400">
        <button
          onClick={() => handleNavigate('https://ubuntu.com/noble-numbat', 'Ubuntu Official')}
          className="hover:text-[#E95420] flex items-center gap-1 font-medium"
        >
          <span>Ubuntu 24.04</span>
        </button>
        <span>·</span>
        <button
          onClick={() => handleNavigate('https://en.wikipedia.org/wiki/Ubuntu', 'Wikipedia')}
          className="hover:text-[#E95420] flex items-center gap-1"
        >
          <span>Wikipedia</span>
        </button>
        <span>·</span>
        <button
          onClick={() => handleNavigate('https://news.ycombinator.com', 'Hacker News')}
          className="hover:text-[#E95420] flex items-center gap-1"
        >
          <span>Hacker News</span>
        </button>
        <span>·</span>
        <button
          onClick={() => handleNavigate('https://duckduckgo.com', 'DuckDuckGo')}
          className="hover:text-[#E95420] flex items-center gap-1"
        >
          <span>DuckDuckGo</span>
        </button>
      </div>

      {/* Browser Viewport Content */}
      <div className="flex-1 bg-white dark:bg-[#181818] overflow-y-auto select-text">
        {/* If Ubuntu page */}
        {activeTab.url.includes('ubuntu.com') ? (
          <div className="max-w-4xl mx-auto p-8">
            <div className="p-8 rounded-2xl bg-gradient-to-br from-[#300A24] via-[#772953] to-[#E95420] text-white shadow-xl mb-8">
              <span className="px-2.5 py-1 bg-white/20 backdrop-blur rounded text-xs font-semibold uppercase tracking-wider">
                LTS Release
              </span>
              <h1 className="text-3xl sm:text-4xl font-bold mt-4 mb-2 tracking-tight">
                Ubuntu 24.04 LTS (Noble Numbat)
              </h1>
              <p className="text-white/80 text-sm max-w-xl leading-relaxed mb-6">
                The latest Long Term Support release brings GNOME 46, Linux Kernel 6.8, enhanced enterprise security, and pristine developer tooling.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => handleNavigate('https://en.wikipedia.org/wiki/Ubuntu', 'Wikipedia: Ubuntu')}
                  className="px-4 py-2 bg-white text-[#300A24] rounded-lg font-semibold text-xs hover:bg-neutral-100 transition-colors"
                >
                  Read Release Whitepaper
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900/40">
                <h3 className="font-bold text-base mb-2 text-neutral-900 dark:text-white">GNOME 46 Desktop</h3>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  Global search improvements, remote login support in GDM, and slick hardware-accelerated animations across the Yaru shell.
                </p>
              </div>
              <div className="p-5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900/40">
                <h3 className="font-bold text-base mb-2 text-neutral-900 dark:text-white">Linux 6.8 Kernel</h3>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  Optimized memory management, Intel Xe and AMD Zen 4 architecture tuning, and updated storage drivers.
                </p>
              </div>
              <div className="p-5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900/40">
                <h3 className="font-bold text-base mb-2 text-neutral-900 dark:text-white">12 Years Support</h3>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  Canonical provides 5 years standard security maintenance plus 7 additional years via Ubuntu Pro.
                </p>
              </div>
            </div>
          </div>
        ) : activeTab.url.includes('wikipedia.org') ? (
          /* Simulated Wikipedia Page */
          <div className="max-w-4xl mx-auto p-8">
            <div className="border-b border-neutral-300 dark:border-neutral-700 pb-4 mb-6 flex items-center justify-between">
              <div>
                <span className="text-2xl font-serif font-bold">WIKIPEDIA</span>
                <span className="text-xs text-neutral-500 ml-2">The Free Encyclopedia</span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setActiveWikiTopic('ubuntu')}
                  className={`px-3 py-1 rounded text-xs font-medium ${
                    activeWikiTopic === 'ubuntu' ? 'bg-[#E95420] text-white' : 'bg-neutral-100 dark:bg-neutral-800'
                  }`}
                >
                  Ubuntu
                </button>
                <button
                  onClick={() => setActiveWikiTopic('linus')}
                  className={`px-3 py-1 rounded text-xs font-medium ${
                    activeWikiTopic === 'linus' ? 'bg-[#E95420] text-white' : 'bg-neutral-100 dark:bg-neutral-800'
                  }`}
                >
                  Linus Torvalds
                </button>
                <button
                  onClick={() => setActiveWikiTopic('gnome')}
                  className={`px-3 py-1 rounded text-xs font-medium ${
                    activeWikiTopic === 'gnome' ? 'bg-[#E95420] text-white' : 'bg-neutral-100 dark:bg-neutral-800'
                  }`}
                >
                  GNOME
                </button>
              </div>
            </div>

            {activeWikiTopic === 'ubuntu' && (
              <div className="space-y-4 text-xs leading-relaxed text-neutral-700 dark:text-neutral-300">
                <h2 className="text-2xl font-serif font-bold text-neutral-900 dark:text-white border-b border-neutral-200 dark:border-neutral-800 pb-2">
                  Ubuntu (operating system)
                </h2>
                <p>
                  <strong>Ubuntu</strong> is a Linux distribution based on Debian and composed mostly of free and open-source software. Ubuntu is officially released in multiple editions: Desktop, Server, and Core for Internet of things devices and robots.
                </p>
                <p>
                  Ubuntu is developed by the British company <strong>Canonical</strong>, and a community of other developers, under a meritocratic governance model. Canonical provides security updates and support for each Ubuntu release, beginning from the release date and until the release reaches its designated end-of-life (EOL) date.
                </p>
                <div className="p-4 bg-neutral-100 dark:bg-neutral-800/60 rounded border-l-4 border-[#E95420] my-4">
                  <p className="italic text-neutral-600 dark:text-neutral-400">
                    "Ubuntu is an ancient African word meaning 'humanity to others'. It is often described as reminding us that 'I am what I am because of who we all are'."
                  </p>
                </div>
              </div>
            )}

            {activeWikiTopic === 'linus' && (
              <div className="space-y-4 text-xs leading-relaxed text-neutral-700 dark:text-neutral-300">
                <h2 className="text-2xl font-serif font-bold text-neutral-900 dark:text-white border-b border-neutral-200 dark:border-neutral-800 pb-2">
                  Linus Benedict Torvalds
                </h2>
                <p>
                  <strong>Linus Benedict Torvalds</strong> (born 28 December 1969) is a Finnish-American software engineer who is the creator and principal developer of the <strong>Linux kernel</strong>, which is used by Linux distributions and other operating systems such as Android.
                </p>
                <p>
                  He also created the distributed version control system <strong>Git</strong> in 2005 for maintaining Linux kernel development.
                </p>
              </div>
            )}

            {activeWikiTopic === 'gnome' && (
              <div className="space-y-4 text-xs leading-relaxed text-neutral-700 dark:text-neutral-300">
                <h2 className="text-2xl font-serif font-bold text-neutral-900 dark:text-white border-b border-neutral-200 dark:border-neutral-800 pb-2">
                  GNOME Desktop
                </h2>
                <p>
                  <strong>GNOME</strong> is a free and open-source desktop environment for Unix-like operating systems. GNOME was originally an acronym for GNU Network Object Model Environment, but the acronym was dropped because it no longer reflected the vision of the project.
                </p>
                <p>
                  Ubuntu switched back to GNOME Shell as its default user interface with Ubuntu 17.10, featuring the custom Yaru theme with Ubuntu orange accents and the Left Dock.
                </p>
              </div>
            )}
          </div>
        ) : activeTab.url.includes('ycombinator.com') ? (
          /* Simulated Hacker News */
          <div className="max-w-4xl mx-auto p-6 bg-[#f6f6ef] dark:bg-[#1a1a1a] min-h-full">
            <div className="bg-[#ff6600] px-3 py-1 flex items-center justify-between text-neutral-900 font-medium text-xs mb-4 rounded-xs">
              <span className="font-bold">Hacker News</span>
              <span className="text-[11px]">new | past | comments | ask | show | jobs</span>
            </div>
            <div className="space-y-3">
              {[
                { title: 'Ubuntu 24.04 LTS Released with GNOME 46 and Linux 6.8', pts: 482, author: 'canonical_fan', time: '3 hours ago', comments: 142 },
                { title: 'Show HN: Interactive Ubuntu Web OS runtime written in React 19', pts: 720, author: 'engineer', time: '5 hours ago', comments: 230 },
                { title: 'Why Linux on the desktop has never felt smoother', pts: 310, author: 'tux_rider', time: '8 hours ago', comments: 98 },
                { title: 'The architecture of modern Wayland and Mutter compositors', pts: 189, author: 'dev_graphics', time: '11 hours ago', comments: 45 },
                { title: 'Writing high-performance audio synthesis in Web Audio API', pts: 256, author: 'synth_coder', time: '14 hours ago', comments: 67 },
              ].map((item, idx) => (
                <div key={idx} className="flex gap-2 text-xs">
                  <span className="text-neutral-400 w-5 text-right">{idx + 1}.</span>
                  <div>
                    <a href="#" className="font-semibold text-neutral-900 dark:text-neutral-100 hover:underline">
                      {item.title}
                    </a>
                    <div className="text-[11px] text-neutral-500 mt-0.5">
                      {item.pts} points by {item.author} {item.time} | {item.comments} comments
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* Generic Webpage / DuckDuckGo search */
          <div className="max-w-xl mx-auto p-12 text-center">
            <div className="w-16 h-16 bg-[#E95420]/10 text-[#E95420] rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Globe className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-bold mb-2">Web Browser</h2>
            <p className="text-xs text-neutral-500 mb-6 leading-relaxed">
              Viewing simulated or external page: <span className="font-mono text-[#E95420]">{activeTab.url}</span>
            </p>
            <div className="flex gap-2 max-w-md mx-auto">
              <input
                type="text"
                placeholder="Search DuckDuckGo or web..."
                className="flex-1 px-3 py-2 text-xs rounded-lg border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 outline-none focus:border-[#E95420]"
              />
              <button
                onClick={() => handleNavigate('https://en.wikipedia.org/wiki/Ubuntu', 'Wikipedia')}
                className="px-4 py-2 bg-[#E95420] text-white rounded-lg text-xs font-semibold hover:bg-[#d84a1b]"
              >
                Search
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
