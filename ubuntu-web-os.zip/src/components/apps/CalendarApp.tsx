/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Trash2, Clock, Calendar as CalIcon } from 'lucide-react';
import { CalendarEvent } from '../../types/os';

const INITIAL_EVENTS: CalendarEvent[] = [
  {
    id: '1',
    title: 'Ubuntu 24.04 LTS Release Party',
    date: '2026-11-04',
    time: '18:00',
    color: '#E95420',
    category: 'Community',
  },
  {
    id: '2',
    title: 'Linux Kernel 6.9 Architecture Review',
    date: '2026-11-08',
    time: '14:30',
    color: '#3584E4',
    category: 'Engineering',
  },
  {
    id: '3',
    title: 'GNOME Design Sprint & Usability Lab',
    date: '2026-11-15',
    time: '10:00',
    color: '#2EC27E',
    category: 'Design',
  },
  {
    id: '4',
    title: 'Canonical Security Audit & CVE Review',
    date: '2026-11-22',
    time: '11:00',
    color: '#E66100',
    category: 'Security',
  },
];

export const CalendarApp: React.FC = () => {
  const [currentDate, setCurrentDate] = useState(new Date(2026, 10, 4)); // November 2026
  const [events, setEvents] = useState<CalendarEvent[]>(INITIAL_EVENTS);
  const [selectedDay, setSelectedDay] = useState(4);
  const [isAddingEvent, setIsAddingEvent] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newTime, setNewTime] = useState('12:00');
  const [newCategory, setNewCategory] = useState('Work');
  const [newColor, setNewColor] = useState('#E95420');

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayIndex = new Date(year, month, 1).getDay();

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
  ];

  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const handleAddEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const formattedDate = `${year}-${String(month + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`;
    const newEvent: CalendarEvent = {
      id: Math.random().toString(),
      title: newTitle.trim(),
      date: formattedDate,
      time: newTime,
      color: newColor,
      category: newCategory,
    };

    setEvents((prev) => [...prev, newEvent]);
    setNewTitle('');
    setIsAddingEvent(false);
  };

  const handleDeleteEvent = (id: string) => {
    setEvents((prev) => prev.filter((ev) => ev.id !== id));
  };

  const selectedDateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`;
  const selectedDayEvents = events.filter((e) => e.date === selectedDateStr);

  return (
    <div className="w-full h-full flex flex-col md:flex-row bg-white dark:bg-[#1E1E1E] text-neutral-800 dark:text-neutral-200 text-sm overflow-hidden select-none">
      {/* Left/Main Calendar Grid */}
      <div className="flex-1 flex flex-col p-4 border-r border-neutral-300 dark:border-neutral-800">
        {/* Month Header and controls */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-white">
              {monthNames[month]} {year}
            </h2>
            <button
              onClick={() => setCurrentDate(new Date(2026, 10, 4))}
              className="text-xs px-2.5 py-1 rounded bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 text-neutral-600 dark:text-neutral-300 font-medium"
            >
              Today
            </button>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={handlePrevMonth}
              className="p-1.5 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleNextMonth}
              className="p-1.5 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsAddingEvent(true)}
              className="ml-2 px-3 py-1 bg-[#E95420] text-white rounded text-xs flex items-center gap-1 font-semibold hover:bg-[#d84a1b]"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Event</span>
            </button>
          </div>
        </div>

        {/* Days of week */}
        <div className="grid grid-cols-7 gap-1 text-center font-semibold text-xs text-neutral-400 mb-2">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
            <div key={d} className="py-1">
              {d}
            </div>
          ))}
        </div>

        {/* Month Days Grid */}
        <div className="flex-1 grid grid-cols-7 gap-1.5">
          {/* Empty cells before month starts */}
          {Array.from({ length: firstDayIndex }).map((_, i) => (
            <div key={`empty-${i}`} className="p-2 rounded-lg bg-neutral-50/50 dark:bg-neutral-900/20" />
          ))}

          {/* Actual days */}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const dayNum = i + 1;
            const isToday = dayNum === 4 && month === 10 && year === 2026;
            const isSelected = dayNum === selectedDay;
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
            const dayEvents = events.filter((e) => e.date === dateStr);

            return (
              <div
                key={dayNum}
                onClick={() => setSelectedDay(dayNum)}
                className={`p-2 rounded-lg cursor-pointer flex flex-col justify-between transition-all border ${
                  isSelected
                    ? 'border-[#E95420] bg-[#E95420]/10 dark:bg-[#E95420]/20'
                    : 'border-neutral-200 dark:border-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-800/60'
                }`}
              >
                <div className="flex justify-between items-start">
                  <span
                    className={`w-6 h-6 flex items-center justify-center rounded-full text-xs font-semibold ${
                      isToday
                        ? 'bg-[#E95420] text-white shadow-xs'
                        : isSelected
                        ? 'text-[#E95420] font-bold'
                        : 'text-neutral-700 dark:text-neutral-300'
                    }`}
                  >
                    {dayNum}
                  </span>
                </div>

                {/* Event dots/chips */}
                <div className="space-y-1 mt-1">
                  {dayEvents.slice(0, 2).map((ev) => (
                    <div
                      key={ev.id}
                      className="text-[10px] px-1.5 py-0.5 rounded truncate font-medium text-white"
                      style={{ backgroundColor: ev.color }}
                      title={ev.title}
                    >
                      {ev.title}
                    </div>
                  ))}
                  {dayEvents.length > 2 && (
                    <div className="text-[9px] text-neutral-400 pl-1">
                      +{dayEvents.length - 2} more
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right Agenda Sidebar */}
      <div className="w-full md:w-72 bg-neutral-50 dark:bg-[#252526] p-4 flex flex-col">
        <h3 className="font-bold text-sm text-neutral-900 dark:text-white mb-1 flex items-center gap-2">
          <CalIcon className="w-4 h-4 text-[#E95420]" />
          <span>Agenda for {monthNames[month]} {selectedDay}</span>
        </h3>
        <p className="text-xs text-neutral-400 mb-4">{selectedDateStr}</p>

        {/* Add event modal / inline form */}
        {isAddingEvent && (
          <form
            onSubmit={handleAddEvent}
            className="p-3 bg-white dark:bg-[#1E1E1E] border border-neutral-300 dark:border-neutral-700 rounded-lg mb-4 space-y-2.5 shadow-sm"
          >
            <div className="text-xs font-bold text-[#E95420]">Create New Event</div>
            <input
              type="text"
              placeholder="Event Title..."
              autoFocus
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="w-full px-2.5 py-1 text-xs rounded border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 outline-none focus:border-[#E95420]"
            />
            <div className="flex gap-2">
              <input
                type="time"
                value={newTime}
                onChange={(e) => setNewTime(e.target.value)}
                className="w-1/2 px-2 py-1 text-xs rounded border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800"
              />
              <select
                value={newColor}
                onChange={(e) => setNewColor(e.target.value)}
                className="w-1/2 px-2 py-1 text-xs rounded border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800"
              >
                <option value="#E95420">Orange</option>
                <option value="#3584E4">Blue</option>
                <option value="#2EC27E">Green</option>
                <option value="#9141AC">Purple</option>
              </select>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setIsAddingEvent(false)}
                className="px-2 py-1 text-xs text-neutral-500 hover:text-neutral-700"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-3 py-1 text-xs bg-[#E95420] text-white rounded font-medium hover:bg-[#d84a1b]"
              >
                Save
              </button>
            </div>
          </form>
        )}

        {/* Selected Day Events List */}
        <div className="flex-1 overflow-y-auto space-y-2">
          {selectedDayEvents.length === 0 ? (
            <div className="text-center py-8 text-neutral-400 text-xs">
              No events scheduled for this date.
            </div>
          ) : (
            selectedDayEvents.map((ev) => (
              <div
                key={ev.id}
                className="p-3 rounded-lg bg-white dark:bg-[#1E1E1E] border border-neutral-200 dark:border-neutral-800 shadow-xs flex items-start justify-between"
              >
                <div>
                  <div className="flex items-center gap-1.5 mb-1">
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: ev.color }}
                    />
                    <span className="font-semibold text-xs text-neutral-900 dark:text-white">
                      {ev.title}
                    </span>
                  </div>
                  <div className="text-[11px] text-neutral-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{ev.time}</span>
                    <span>·</span>
                    <span>{ev.category}</span>
                  </div>
                </div>
                <button
                  onClick={() => handleDeleteEvent(ev.id)}
                  className="text-neutral-400 hover:text-red-500 p-1"
                  title="Delete event"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
