/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { AppId, SystemSettings, WindowInstance, FileItem } from './types/os';
import { APPS_REGISTRY, WALLPAPERS } from './data/appsData';
import { TopBar } from './components/shell/TopBar';
import { Dock } from './components/shell/Dock';
import { WindowFrame } from './components/shell/WindowFrame';
import { ActivitiesOverview } from './components/shell/ActivitiesOverview';
import { DesktopIcons } from './components/shell/DesktopIcons';
import { ContextMenu } from './components/shell/ContextMenu';
import { LockScreen } from './components/shell/LockScreen';
import { PowerDialog } from './components/shell/PowerDialog';
import { soundService } from './services/soundEffects';
import { mockFS } from './services/mockFileSystem';

// Applications
import { TerminalApp } from './components/apps/TerminalApp';
import { FilesApp } from './components/apps/FilesApp';
import { BrowserApp } from './components/apps/BrowserApp';
import { EditorApp } from './components/apps/EditorApp';
import { CalculatorApp } from './components/apps/CalculatorApp';
import { CalendarApp } from './components/apps/CalendarApp';
import { MusicApp } from './components/apps/MusicApp';
import { ImageViewerApp } from './components/apps/ImageViewerApp';
import { SoftwareApp } from './components/apps/SoftwareApp';
import { SettingsApp } from './components/apps/SettingsApp';
import { MinesweeperApp } from './components/apps/MinesweeperApp';

const DEFAULT_SETTINGS: SystemSettings = {
  theme: 'dark',
  accentColor: '#E95420',
  accentName: 'Orange (Default)',
  wallpaper: WALLPAPERS[0].css,
  wallpaperName: WALLPAPERS[0].name,
  dockPosition: 'left',
  dockIconSize: 48,
  dockAutoHide: false,
  showDesktopIcons: true,
  volume: 75,
  isMuted: false,
  brightness: 100,
  wifiEnabled: true,
  bluetoothEnabled: true,
  nightLight: false,
  nightLightWarmth: 30,
  powerMode: 'performance',
};

export default function App() {
  const [settings, setSettings] = useState<SystemSettings>(() => {
    try {
      const stored = localStorage.getItem('ubuntu_settings_v1');
      return stored ? { ...DEFAULT_SETTINGS, ...JSON.parse(stored) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  const [windows, setWindows] = useState<WindowInstance[]>([
    {
      id: 'win-terminal',
      appId: 'terminal',
      title: 'Terminal - bash',
      x: 100,
      y: 60,
      width: 720,
      height: 460,
      zIndex: 101,
      isMinimized: false,
      isMaximized: false,
    },
    {
      id: 'win-files',
      appId: 'files',
      title: 'Files - /home/ubuntu',
      x: 180,
      y: 110,
      width: 820,
      height: 520,
      zIndex: 102,
      isMinimized: false,
      isMaximized: false,
    },
  ]);

  const [activeWindowId, setActiveWindowId] = useState<string | null>('win-files');
  const [highestZ, setHighestZ] = useState(105);
  const [cascadeCount, setCascadeCount] = useState(2);

  // Shell UI states
  const [isActivitiesOpen, setIsActivitiesOpen] = useState(false);
  const [isAppGridOpen, setIsAppGridOpen] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [isPowerDialogOpen, setIsPowerDialogOpen] = useState(false);

  // Desktop right-click context menu
  const [contextMenu, setContextMenu] = useState<{
    isOpen: boolean;
    x: number;
    y: number;
  }>({ isOpen: false, x: 0, y: 0 });

  // Sync dark class on document element for Tailwind v4
  useEffect(() => {
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    try {
      localStorage.setItem('ubuntu_settings_v1', JSON.stringify(settings));
    } catch {}
  }, [settings]);

  const handleUpdateSettings = (partial: Partial<SystemSettings>) => {
    setSettings((prev) => ({ ...prev, ...partial }));
  };

  // Focus Window
  const handleFocusWindow = useCallback(
    (winId: string) => {
      setHighestZ((prev) => {
        const nextZ = prev + 1;
        setWindows((wList) =>
          wList.map((w) => (w.id === winId ? { ...w, zIndex: nextZ, isMinimized: false } : w))
        );
        return nextZ;
      });
      setActiveWindowId(winId);
    },
    []
  );

  // Launch or Restore App
  const handleLaunchApp = useCallback(
    (appId: AppId, params?: Record<string, any>) => {
      // Check if window already exists
      const existing = windows.find((w) => w.appId === appId);
      if (existing) {
        handleFocusWindow(existing.id);
        if (params) {
          setWindows((prev) =>
            prev.map((w) => (w.id === existing.id ? { ...w, params: { ...w.params, ...params } } : w))
          );
        }
        return;
      }

      // Create new window with cascading coordinates
      const meta = APPS_REGISTRY[appId] || {
        name: appId,
        defaultWidth: 700,
        defaultHeight: 480,
      };

      const offset = (cascadeCount % 8) * 28;
      setCascadeCount((c) => c + 1);

      const nextZ = highestZ + 1;
      setHighestZ(nextZ);

      const newWin: WindowInstance = {
        id: `win-${appId}-${Date.now()}`,
        appId,
        title: meta.name,
        x: Math.min(window.innerWidth - meta.defaultWidth - 20, 100 + offset),
        y: Math.min(window.innerHeight - meta.defaultHeight - 30, 60 + offset),
        width: Math.min(window.innerWidth - 120, meta.defaultWidth),
        height: Math.min(window.innerHeight - 80, meta.defaultHeight),
        zIndex: nextZ,
        isMinimized: false,
        isMaximized: false,
        params,
      };

      setWindows((prev) => [...prev, newWin]);
      setActiveWindowId(newWin.id);
      soundService.playWindowOpen();
    },
    [windows, cascadeCount, highestZ, handleFocusWindow]
  );

  // Dock Click handler
  const handleDockAppClick = (appId: AppId) => {
    const existing = windows.find((w) => w.appId === appId);
    if (!existing) {
      handleLaunchApp(appId);
    } else {
      if (existing.id === activeWindowId && !existing.isMinimized) {
        // Toggle minimize if already active
        handleMinimizeWindow(existing.id);
      } else {
        handleFocusWindow(existing.id);
      }
    }
  };

  const handleCloseWindow = (winId: string) => {
    setWindows((prev) => prev.filter((w) => w.id !== winId));
    if (activeWindowId === winId) {
      const remaining = windows.filter((w) => w.id !== winId);
      if (remaining.length > 0) {
        const top = remaining.reduce((max, w) => (w.zIndex > max.zIndex ? w : max), remaining[0]);
        setActiveWindowId(top.id);
      } else {
        setActiveWindowId(null);
      }
    }
  };

  const handleMinimizeWindow = (winId: string) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === winId ? { ...w, isMinimized: true } : w))
    );
    if (activeWindowId === winId) {
      const available = windows.filter((w) => w.id !== winId && !w.isMinimized);
      if (available.length > 0) {
        const top = available.reduce((max, w) => (w.zIndex > max.zIndex ? w : max), available[0]);
        setActiveWindowId(top.id);
      } else {
        setActiveWindowId(null);
      }
    }
  };

  const handleToggleMaximize = (winId: string) => {
    setWindows((prev) =>
      prev.map((w) => {
        if (w.id !== winId) return w;
        if (w.isMaximized) {
          // Restore
          return {
            ...w,
            isMaximized: false,
            isSnapped: null,
            x: w.prevBounds?.x || 100,
            y: w.prevBounds?.y || 60,
            width: w.prevBounds?.width || 700,
            height: w.prevBounds?.height || 480,
          };
        } else {
          // Maximize
          return {
            ...w,
            isMaximized: true,
            isSnapped: null,
            prevBounds: { x: w.x, y: w.y, width: w.width, height: w.height },
          };
        }
      })
    );
    handleFocusWindow(winId);
  };

  const handleSnapWindow = (winId: string, side: 'left' | 'right' | null) => {
    setWindows((prev) =>
      prev.map((w) => {
        if (w.id !== winId) return w;
        return {
          ...w,
          isSnapped: side,
          isMaximized: false,
          prevBounds: w.prevBounds || { x: w.x, y: w.y, width: w.width, height: w.height },
        };
      })
    );
    handleFocusWindow(winId);
  };

  const handleUpdateBounds = (
    winId: string,
    bounds: { x: number; y: number; width: number; height: number }
  ) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === winId ? { ...w, ...bounds, isMaximized: false, isSnapped: null } : w))
    );
  };

  // Desktop right-click
  const handleDesktopContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    setContextMenu({
      isOpen: true,
      x: e.clientX,
      y: e.clientY,
    });
  };

  // Keyboard global shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+Alt+T -> Terminal
      if (e.ctrlKey && e.altKey && e.key.toLowerCase() === 't') {
        e.preventDefault();
        handleLaunchApp('terminal');
      }
      // Super / Windows key -> Activities
      if (e.key === 'Meta' || (e.altKey && e.key === 'F1')) {
        e.preventDefault();
        setIsActivitiesOpen((prev) => !prev);
      }
      // Escape closes activities
      if (e.key === 'Escape') {
        setIsActivitiesOpen(false);
        setIsAppGridOpen(false);
        setContextMenu((prev) => ({ ...prev, isOpen: false }));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleLaunchApp]);

  const activeWindow = windows.find((w) => w.id === activeWindowId) || null;

  // Render client component for a window instance
  const renderAppContent = (win: WindowInstance) => {
    switch (win.appId) {
      case 'terminal':
        return <TerminalApp onLaunchApp={(app) => handleLaunchApp(app as AppId)} />;
      case 'files':
        return (
          <FilesApp
            initialPath={win.params?.path || '/home/ubuntu'}
            onOpenFile={(file) => {
              if (file.type === 'file') {
                const ext = file.extension?.toLowerCase();
                if (ext === 'svg' || ext === 'png' || ext === 'jpg') {
                  handleLaunchApp('imageviewer', { file });
                } else {
                  handleLaunchApp('editor', { file });
                }
              }
            }}
          />
        );
      case 'browser':
        return <BrowserApp />;
      case 'editor':
        return <EditorApp initialFile={win.params?.file || null} />;
      case 'calc':
        return <CalculatorApp />;
      case 'calendar':
        return <CalendarApp />;
      case 'music':
        return <MusicApp />;
      case 'imageviewer':
        return (
          <ImageViewerApp
            initialFile={win.params?.file || null}
            onSetWallpaper={(css, name) => handleUpdateSettings({ wallpaper: css, wallpaperName: name })}
          />
        );
      case 'software':
        return <SoftwareApp onLaunchApp={(app) => handleLaunchApp(app as AppId)} />;
      case 'settings':
        return (
          <SettingsApp
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
          />
        );
      case 'minesweeper':
        return <MinesweeperApp />;
      default:
        return (
          <div className="p-8 text-center text-neutral-500">
            Application: {win.appId}
          </div>
        );
    }
  };

  return (
    <div
      className="w-screen h-screen overflow-hidden relative select-none font-sans"
      style={{
        filter: `brightness(${settings.brightness}%)`,
      }}
    >
      {/* Night Light Warm Amber Filter Overlay */}
      {settings.nightLight && (
        <div
          className="fixed inset-0 pointer-events-none z-[99990] transition-opacity duration-300"
          style={{
            backgroundColor: '#ff8800',
            opacity: (settings.nightLightWarmth || 30) / 100 * 0.35,
            mixBlendMode: 'multiply',
          }}
        />
      )}

      {/* Desktop Canvas Background */}
      <div
        onContextMenu={handleDesktopContextMenu}
        className="absolute inset-0 transition-all duration-300 bg-cover bg-center"
        style={{ background: settings.wallpaper }}
      >
        {/* Desktop Icons */}
        {settings.showDesktopIcons && (
          <DesktopIcons
            onOpenFolder={(path) => handleLaunchApp('files', { path })}
            onOpenFile={(file) => {
              const ext = file.extension?.toLowerCase();
              if (ext === 'svg' || ext === 'png' || ext === 'jpg') {
                handleLaunchApp('imageviewer', { file });
              } else {
                handleLaunchApp('editor', { file });
              }
            }}
            onOpenTrash={() => handleLaunchApp('files', { path: '/home/ubuntu/.local/share/Trash' })}
          />
        )}
      </div>

      {/* GNOME Top Bar */}
      <TopBar
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        activeWindow={activeWindow}
        onToggleActivities={() => setIsActivitiesOpen(!isActivitiesOpen)}
        isActivitiesOpen={isActivitiesOpen}
        onLockScreen={() => setIsLocked(true)}
        onOpenPowerDialog={() => setIsPowerDialogOpen(true)}
        onLaunchApp={(app) => handleLaunchApp(app as AppId)}
      />

      {/* Left Ubuntu Dock */}
      <Dock
        settings={settings}
        openWindows={windows}
        activeWindowId={activeWindowId}
        onAppClick={handleDockAppClick}
        onToggleAppGrid={() => setIsActivitiesOpen(!isActivitiesOpen)}
        isAppGridOpen={isActivitiesOpen}
      />

      {/* Window Manager Layer */}
      {windows.map((win) => (
        <WindowFrame
          key={win.id}
          window={win}
          isActive={win.id === activeWindowId}
          onFocus={() => handleFocusWindow(win.id)}
          onClose={() => handleCloseWindow(win.id)}
          onMinimize={() => handleMinimizeWindow(win.id)}
          onToggleMaximize={() => handleToggleMaximize(win.id)}
          onSnap={(side) => handleSnapWindow(win.id, side)}
          onUpdateBounds={(b) => handleUpdateBounds(win.id, b)}
        >
          {renderAppContent(win)}
        </WindowFrame>
      ))}

      {/* Desktop Right Click Context Menu */}
      <ContextMenu
        x={contextMenu.x}
        y={contextMenu.y}
        isOpen={contextMenu.isOpen}
        onClose={() => setContextMenu((prev) => ({ ...prev, isOpen: false }))}
        onCreateFolder={() => {
          mockFS.createFolder('/home/ubuntu/Desktop', 'New Folder');
        }}
        onCreateFile={() => {
          mockFS.createFile('/home/ubuntu/Desktop', 'New Document.txt', '');
        }}
        onOpenSettings={(tab) => handleLaunchApp('settings')}
        onOpenTerminal={() => handleLaunchApp('terminal')}
      />

      {/* Activities Overview (Search & Window Workspace Expose) */}
      <ActivitiesOverview
        isOpen={isActivitiesOpen}
        onClose={() => setIsActivitiesOpen(false)}
        openWindows={windows}
        onSelectWindow={(winId) => {
          handleFocusWindow(winId);
          setIsActivitiesOpen(false);
        }}
        onCloseWindow={(winId) => handleCloseWindow(winId)}
        onLaunchApp={(appId, params) => {
          handleLaunchApp(appId, params);
          setIsActivitiesOpen(false);
        }}
        isAppGridMode={isAppGridOpen}
      />

      {/* Lock Screen */}
      <LockScreen
        isLocked={isLocked}
        onUnlock={() => setIsLocked(false)}
        wallpaper={settings.wallpaper}
      />

      {/* Power Dialog */}
      <PowerDialog
        isOpen={isPowerDialogOpen}
        onClose={() => setIsPowerDialogOpen(false)}
        onRestart={() => {
          setIsPowerDialogOpen(false);
          window.location.reload();
        }}
        onPowerOff={() => {
          setIsPowerDialogOpen(false);
          setIsLocked(true);
        }}
      />
    </div>
  );
}
