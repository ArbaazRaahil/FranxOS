/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FileItem } from '../types/os';

const STORAGE_KEY = 'ubuntu_web_fs_v1';

const INITIAL_FILES: FileItem[] = [
  // Home Folders
  { id: '1', name: 'Desktop', path: '/home/ubuntu/Desktop', type: 'folder', updatedAt: '2026-11-04 10:00' },
  { id: '2', name: 'Documents', path: '/home/ubuntu/Documents', type: 'folder', updatedAt: '2026-11-04 10:00' },
  { id: '3', name: 'Downloads', path: '/home/ubuntu/Downloads', type: 'folder', updatedAt: '2026-11-04 10:00' },
  { id: '4', name: 'Music', path: '/home/ubuntu/Music', type: 'folder', updatedAt: '2026-11-04 10:00' },
  { id: '5', name: 'Pictures', path: '/home/ubuntu/Pictures', type: 'folder', updatedAt: '2026-11-04 10:00' },
  { id: '6', name: 'Videos', path: '/home/ubuntu/Videos', type: 'folder', updatedAt: '2026-11-04 10:00' },

  // Desktop files
  {
    id: '10',
    name: 'Welcome.txt',
    path: '/home/ubuntu/Desktop/Welcome.txt',
    type: 'file',
    extension: 'txt',
    size: 640,
    updatedAt: '2026-11-04 10:15',
    content: `Welcome to Ubuntu 24.04 LTS (Noble Numbat) Web Edition!

This is a production-grade Web OS environment built with React 19, TypeScript, and modern GNOME Yaru design principles.

Key Features & Shortcuts:
- Top Bar: Activities overview, GNOME Calendar & Quick Settings
- Left Dock: Launch, focus, or minimize apps with running indicator pips
- Window Management: Drag titlebars, resize from edges, snap left/right or double-click to maximize
- Terminal: Interactive bash shell with 'neofetch', 'matrix', 'htop', 'cowsay', and filesystem commands
- Files: Real Nautilus file explorer with create, open, edit, and preview
- Text Editor: Gedit with markdown preview, line numbers, and file saving
- Web Browser: Functional browser with search, Wikipedia integration, and bookmarks
- Settings: Dark/Light mode, Yaru accent colors, wallpaper gallery, and system monitors

Enjoy exploring Ubuntu in your browser!
`,
  },
  {
    id: '11',
    name: 'System_Info.md',
    path: '/home/ubuntu/Desktop/System_Info.md',
    type: 'file',
    extension: 'md',
    size: 420,
    updatedAt: '2026-11-04 10:20',
    content: `# Ubuntu 24.04 LTS Architecture

- **OS**: Ubuntu 24.04 LTS (Noble Numbat)
- **Desktop Environment**: GNOME 46 (Yaru Theme)
- **Window Manager**: Mutter (HTML5 Compositor)
- **Runtime**: React 19 + TypeScript + Tailwind CSS
- **Audio Engine**: Web Audio Synth API
- **Shell**: Bash 5.2 Emulation

Open this file in **Text Editor** to view and edit!
`,
  },

  // Documents
  {
    id: '20',
    name: 'Project_Checklist.txt',
    path: '/home/ubuntu/Documents/Project_Checklist.txt',
    type: 'file',
    extension: 'txt',
    size: 280,
    updatedAt: '2026-11-04 10:30',
    content: `[x] Linux Bash Terminal with NeoFetch & HTop
[x] Nautilus File Manager with Home directories
[x] GNOME Yaru window manager with snap & cascade
[x] Full Gedit text editor with live markdown
[x] Web Browser with Wikipedia and quick links
[x] Calculator with basic and scientific modes
[x] Ambient Music Player with Web Audio synthesizers
[x] Settings with authentic wallpapers and accent colors
`,
  },
  {
    id: '21',
    name: 'Server_Configuration.json',
    path: '/home/ubuntu/Documents/Server_Configuration.json',
    type: 'file',
    extension: 'json',
    size: 340,
    updatedAt: '2026-11-04 10:45',
    content: `{
  "hostname": "ubuntu-noble-station",
  "timezone": "UTC",
  "networking": {
    "interface": "wlan0",
    "ip": "192.168.1.104",
    "gateway": "192.168.1.1"
  },
  "services": {
    "ssh": "active",
    "docker": "running",
    "gnome-shell": "active"
  }
}`,
  },

  // Downloads
  {
    id: '30',
    name: 'ubuntu-24.04-desktop-amd64.iso',
    path: '/home/ubuntu/Downloads/ubuntu-24.04-desktop-amd64.iso',
    type: 'file',
    extension: 'iso',
    size: 4831838208,
    updatedAt: '2026-11-04 11:00',
    content: '[Binary ISO Disc Image - Ubuntu 24.04 LTS 64-bit]',
  },
  {
    id: '31',
    name: 'linux-cheat-sheet.pdf',
    path: '/home/ubuntu/Downloads/linux-cheat-sheet.pdf',
    type: 'file',
    extension: 'pdf',
    size: 154800,
    updatedAt: '2026-11-04 11:10',
    content: '[PDF Document - Linux Terminal Quick Reference]',
  },

  // Pictures (with SVG data for image viewer preview)
  {
    id: '40',
    name: 'Noble_Numbat.svg',
    path: '/home/ubuntu/Pictures/Noble_Numbat.svg',
    type: 'file',
    extension: 'svg',
    size: 1420,
    updatedAt: '2026-11-04 11:20',
    content: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" width="100%" height="100%">
  <defs>
    <radialGradient id="g1" cx="70%" cy="30%" r="80%">
      <stop offset="0%" stop-color="#E95420"/>
      <stop offset="50%" stop-color="#772953"/>
      <stop offset="100%" stop-color="#300A24"/>
    </radialGradient>
  </defs>
  <rect width="400" height="300" fill="url(#g1)"/>
  <circle cx="200" cy="150" r="70" fill="none" stroke="rgba(255,255,255,0.25)" stroke-width="4"/>
  <circle cx="200" cy="150" r="45" fill="none" stroke="#E95420" stroke-width="6"/>
  <polygon points="200,90 230,170 170,170" fill="rgba(255,255,255,0.7)"/>
  <text x="200" y="250" text-anchor="middle" fill="#ffffff" font-family="Ubuntu, sans-serif" font-size="20" font-weight="bold">Ubuntu 24.04 LTS</text>
  <text x="200" y="275" text-anchor="middle" fill="rgba(255,255,255,0.7)" font-family="Ubuntu, sans-serif" font-size="12">Noble Numbat</text>
</svg>`,
  },
  {
    id: '41',
    name: 'Aubergine_Sunset.svg',
    path: '/home/ubuntu/Pictures/Aubergine_Sunset.svg',
    type: 'file',
    extension: 'svg',
    size: 1100,
    updatedAt: '2026-11-04 11:25',
    content: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" width="100%" height="100%">
  <defs>
    <linearGradient id="g2" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#300A24"/>
      <stop offset="40%" stop-color="#5E2750"/>
      <stop offset="80%" stop-color="#E95420"/>
      <stop offset="100%" stop-color="#FFA447"/>
    </linearGradient>
  </defs>
  <rect width="400" height="300" fill="url(#g2)"/>
  <circle cx="280" cy="140" r="50" fill="#FFA447" opacity="0.85"/>
  <path d="M0,230 Q120,180 220,240 T400,220 L400,300 L0,300 Z" fill="#200418"/>
  <path d="M0,250 Q160,210 280,260 T400,245 L400,300 L0,300 Z" fill="#13010E"/>
  <text x="40" y="50" fill="#ffffff" font-family="Ubuntu, sans-serif" font-size="18" font-weight="500">Ubuntu Dusk Landscape</text>
</svg>`,
  },
];

type Listener = () => void;

class MockFileSystem {
  private files: FileItem[] = [];
  private listeners: Set<Listener> = new Set();

  constructor() {
    this.load();
  }

  private load() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        this.files = JSON.parse(stored);
      } else {
        this.files = INITIAL_FILES;
        this.save();
      }
    } catch {
      this.files = INITIAL_FILES;
    }
  }

  private save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.files));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
    this.notify();
  }

  public subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  public getDirectoryContents(dirPath: string): FileItem[] {
    const cleanPath = dirPath.endsWith('/') && dirPath !== '/' ? dirPath.slice(0, -1) : dirPath;
    return this.files.filter((item) => {
      const lastSlashIndex = item.path.lastIndexOf('/');
      const parentDir = lastSlashIndex === 0 ? '/' : item.path.substring(0, lastSlashIndex);
      return parentDir === cleanPath;
    });
  }

  public getFileByPath(path: string): FileItem | undefined {
    return this.files.find((f) => f.path === path);
  }

  public createFile(parentPath: string, name: string, content = ''): FileItem {
    const cleanParent = parentPath.endsWith('/') && parentPath !== '/' ? parentPath.slice(0, -1) : parentPath;
    const path = `${cleanParent}/${name}`;
    const ext = name.includes('.') ? name.split('.').pop() : undefined;
    const now = new Date().toISOString().slice(0, 16).replace('T', ' ');

    const newFile: FileItem = {
      id: Math.random().toString(36).substring(2, 9),
      name,
      path,
      type: 'file',
      extension: ext,
      size: content.length,
      content,
      updatedAt: now,
    };

    // Remove existing file with same name if any
    this.files = this.files.filter((f) => f.path !== path);
    this.files.push(newFile);
    this.save();
    return newFile;
  }

  public createFolder(parentPath: string, name: string): FileItem {
    const cleanParent = parentPath.endsWith('/') && parentPath !== '/' ? parentPath.slice(0, -1) : parentPath;
    const path = `${cleanParent}/${name}`;
    const now = new Date().toISOString().slice(0, 16).replace('T', ' ');

    const newFolder: FileItem = {
      id: Math.random().toString(36).substring(2, 9),
      name,
      path,
      type: 'folder',
      updatedAt: now,
    };

    this.files = this.files.filter((f) => f.path !== path);
    this.files.push(newFolder);
    this.save();
    return newFolder;
  }

  public updateFileContent(path: string, content: string): boolean {
    const file = this.files.find((f) => f.path === path);
    if (!file) return false;
    file.content = content;
    file.size = content.length;
    file.updatedAt = new Date().toISOString().slice(0, 16).replace('T', ' ');
    this.save();
    return true;
  }

  public deleteItem(path: string): boolean {
    const item = this.files.find((f) => f.path === path);
    if (!item) return false;

    // Delete item and any children if it's a folder
    this.files = this.files.filter((f) => f.path !== path && !f.path.startsWith(path + '/'));
    this.save();
    return true;
  }

  public renameItem(oldPath: string, newName: string): boolean {
    const item = this.files.find((f) => f.path === oldPath);
    if (!item) return false;

    const parentDir = oldPath.substring(0, oldPath.lastIndexOf('/'));
    const newPath = `${parentDir}/${newName}`;
    const ext = newName.includes('.') ? newName.split('.').pop() : undefined;

    item.name = newName;
    item.path = newPath;
    if (item.type === 'file') {
      item.extension = ext;
    }

    // If folder, update all child paths
    if (item.type === 'folder') {
      this.files.forEach((f) => {
        if (f.path.startsWith(oldPath + '/')) {
          f.path = f.path.replace(oldPath, newPath);
        }
      });
    }

    this.save();
    return true;
  }

  public search(query: string): FileItem[] {
    const q = query.toLowerCase();
    return this.files.filter((f) => f.name.toLowerCase().includes(q));
  }

  public resetToDefault() {
    this.files = INITIAL_FILES;
    this.save();
  }
}

export const mockFS = new MockFileSystem();
