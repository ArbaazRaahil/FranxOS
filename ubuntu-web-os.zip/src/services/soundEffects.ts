/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class SoundService {
  private ctx: AudioContext | null = null;
  private musicOsc: OscillatorNode | null = null;
  private musicGain: GainNode | null = null;
  private isPlayingMusic = false;
  private musicTimer: any = null;
  private currentNoteIndex = 0;

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public playBeep(freq = 440, type: OscillatorType = 'sine', duration = 0.15, volume = 0.2) {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);

      gain.gain.setValueAtTime(volume, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {
      // Audio might be blocked by browser policy until interaction
    }
  }

  public playWindowOpen() {
    this.playBeep(520, 'sine', 0.1, 0.1);
  }

  public playWindowClose() {
    this.playBeep(320, 'sine', 0.12, 0.1);
  }

  public playNotification() {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.setValueAtTime(880, now + 0.1); // A5

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.35);
    } catch {}
  }

  public playTestChime() {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      [440, 554.37, 659.25].forEach((f, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(f, now + idx * 0.08);
        gain.gain.setValueAtTime(0.12, now + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.3);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.35);
      });
    } catch {}
  }

  // Synthesizer track playback for Rhythmbox
  public startAmbientTrack(trackType: number, onNote?: (noteFreq: number) => void) {
    this.stopAmbientTrack();
    const ctx = this.getAudioContext();
    if (!ctx) return;

    this.isPlayingMusic = true;

    // Pentatonic scales for chill ambient vibe
    const scales: number[][] = [
      [220, 261.63, 293.66, 329.63, 392, 440, 523.25], // A minor
      [196, 220, 246.94, 293.66, 329.63, 392], // G major
      [174.61, 220, 261.63, 293.66, 349.23, 440], // F Lydian
    ];

    const currentScale = scales[trackType % scales.length];

    this.musicTimer = setInterval(() => {
      if (!this.isPlayingMusic) return;
      const noteFreq = currentScale[this.currentNoteIndex % currentScale.length];
      this.currentNoteIndex = (this.currentNoteIndex + Math.floor(Math.random() * 3) + 1) % currentScale.length;

      try {
        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const filter = ctx.createBiquadFilter();
        const gain = ctx.createGain();

        osc.type = trackType === 1 ? 'sawtooth' : 'triangle';
        osc.frequency.setValueAtTime(noteFreq, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(800, now);

        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.2);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + 1.3);

        if (onNote) onNote(noteFreq);
      } catch {}
    }, 600);
  }

  public stopAmbientTrack() {
    this.isPlayingMusic = false;
    if (this.musicTimer) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }

  public isMusicPlaying(): boolean {
    return this.isPlayingMusic;
  }
}

export const soundService = new SoundService();
