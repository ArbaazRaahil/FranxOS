/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AppId =
  | 'terminal'
  | 'files'
  | 'browser'
  | 'editor'
  | 'calc'
  | 'calendar'
  | 'settings'
  | 'imageviewer'
  | 'music'
  | 'software'
  | 'minesweeper';

export interface AppMetadata {
  id: AppId;
  name: string;
  genericName?: string;
  icon: string; // Icon identifier or name
  description: string;
  category: 'System' | 'Utilities' | 'Internet' | 'Office' | 'Media' | 'Games';
  defaultWidth: number;
  defaultHeight: number;
  isPinned: boolean;
}

export interface WindowInstance {
  id: string;
  appId: AppId;
  title: string;
  x: number;
  y: number;
  width: number;
  height: number;
  prevBounds?: { x: number; y: number; width: number; height: number };
  zIndex: number;
  isMinimized: boolean;
  isMaximized: boolean;
  isSnapped?: 'left' | 'right' | null;
  params?: Record<string, any>;
}

export interface SystemSettings {
  theme: 'dark' | 'light';
  accentColor: string;
  accentName: string;
  wallpaper: string;
  wallpaperName: string;
  dockPosition: 'left' | 'bottom';
  dockIconSize: number;
  dockAutoHide: boolean;
  showDesktopIcons: boolean;
  volume: number;
  isMuted: boolean;
  brightness: number;
  wifiEnabled: boolean;
  bluetoothEnabled: boolean;
  nightLight: boolean;
  nightLightWarmth: number;
  powerMode: 'performance' | 'balanced' | 'power-saver';
}

export interface FileItem {
  id: string;
  name: string;
  path: string;
  type: 'file' | 'folder';
  size?: number; // in bytes
  content?: string;
  extension?: string;
  updatedAt: string;
  icon?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  time?: string;
  color: string;
  category: string;
}
